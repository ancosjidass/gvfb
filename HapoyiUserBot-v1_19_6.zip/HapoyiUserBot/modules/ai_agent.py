"""AI account control (1.17.0): tell the AI what you want in your own words, it operates the self for you.

    .do <request>                 e.g.  .do هر 5 دقیقه بنویس میو          -> .every 5m میو
                                        .do اتو ریپلای کن: هر کس نوشت علیک بگو سلام   -> .autoreply add علیک => سلام
                                        (Reply on a link)  .do با کیفیت 720 دانلودش کن  -> .dl 720 <link>
                                  (aliases: .act  .agent)
    .ai control on|off|status     the FIRST `.do` asks «اجازهٔ دائمی کنترل اکانت را به من می‌دهی؟» (once); until you answer «بله» nothing runs
    .ai control danger on|off     off (default, 1.17.2): EVERY command runs at once (ban, mute, blacklist, purge ...); on: sensitive ones wait for «بله»
    .ai control log               the last things the AI did for you
    .ai yes | .ai no              the same as writing «بله» / «نه» when something waits for your answer

How it works: the model only PLANS (services/aiagent.py); the bot sends the commands with your account, so every feature of the self
works (downloads with quality, timers, auto-reply, fake actions ...) and every normal rule of each command still applies.
Every command of the self can be sent (1.17.2); only `.do` inside `.do` is refused (endless loop).
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import re
import time
from collections import deque
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events
from telethon.errors import FloodWaitError
from telethon.tl.types import PeerUser

from core.identity import my_id, my_name
from services import aiagent as A
from services import knowledge as K
from services.aithreads import publish

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
GRANT_KEY, DANGER_KEY, LOG_KEY = "ai_ctl_granted", "ai_ctl_danger", "ai_ctl_log"
SETTLE = 0.3  # seconds the handlers of the commands just sent get before answers («بله») are listened to again

USAGE = (f"فرمت: `{PREFIX}do درخواستت به زبان خودت`\n"
         f"مثال: `{PREFIX}do هر ۵ دقیقه بنویس میو` | `{PREFIX}do اتو ریپلای: هر کس نوشت علیک بگو سلام` | (Reply روی لینک) `{PREFIX}do با کیفیت 720 دانلودش کن`\n"
         f"دسترسی: `{PREFIX}ai control on|off|status` | `{PREFIX}ai control log`")

GRANT_TEXT = (
    "🔐 اجازهٔ کنترل اکانت\n\n"
    "برای انجام درخواستت باید دستورهای سلف رو از طرف اکانتت بفرستم (مثل .every ، .dl ، .autoreply ، .fake …) — دقیقاً مثل اینکه خودت تایپ کرده باشی.\n"
    "آیا اجازهٔ دائمی کنترل این اکانت (فقط از راه دستورهای خود سلف) رو به من می‌دی؟\n\n"
    "• دستورهای حساس (بن، پاک‌کردن پیام، ارتقا، اکو …) هر بار قبل از اجرا ازت «بله» می‌خوان.\n"
    "• بعضی دستورها (لایسنس، بکاپ/ریستور، ماکرو …) هیچ‌وقت توسط AI اجرا نمی‌شن.\n"
    f"• هر وقت خواستی: `{PREFIX}ai control off`\n\n"
    f"بنویس «بله» یا «نه» (تا {A.PENDING_TTL // 60} دقیقه) — یا `{PREFIX}ai yes` / `{PREFIX}ai no`.")


def setup(client, db):
    st = {"tasks": set(), "pending": {}, "executing": False, "times": deque(), "sent": deque(maxlen=200)}

    def known() -> set[str]:
        return (K.known_commands() | {"storage", "reply"} | handler_commands()) - set(A.BLOCKED)

    async def granted() -> bool:
        # one-time permission: until the owner answers «بله» (or `.ai control on`) NOTHING is run; every `.do` asks again until then
        return bool(await db.get_kv(GRANT_KEY, False))

    async def danger_on() -> bool:
        return bool(await db.get_kv(DANGER_KEY, False))

    def handler_commands() -> set[str]:
        """Every command that really has a handler in this process (so nothing that exists is ever called «ناشناخته»)."""
        out: set[str] = set()
        try:
            handlers = client.list_event_handlers()
        except Exception:  # noqa: BLE001
            return out
        for _cb, builder in handlers:  # Telethon returns (callback, event)
            pat = getattr(builder, "pattern", None)
            src = getattr(getattr(pat, "__self__", None), "pattern", None) or (pat if isinstance(pat, str) else None)
            if not isinstance(src, str):
                continue
            body = re.sub(r"^(\(\?[a-zA-Z]+\))+", "", src).lstrip("^")
            if not body.startswith(P):
                continue
            body = body[len(P):]
            flat = body.replace("(?:", "(")  # (?:a|b) -> (a|b)
            for n in re.findall(r"(?:^|[(|?)])([A-Za-z0-9][A-Za-z0-9_]+)", flat[:90]):
                out.add(n.lower())
        return out

    def ask_fn():
        return getattr(client, "_hapoyi_ask_ai", None)

    # ------------------------------------------------------------------ what the AI is told about the replied message (links only, never the text)
    def media_kind(m) -> str:
        for attr, label in (("photo", "photo"), ("video", "video"), ("voice", "voice message"), ("audio", "audio"), ("sticker", "sticker"), ("gif", "gif"), ("document", "file")):
            if getattr(m, attr, None):
                return label
        return "text message"

    async def reply_info(replied):
        if replied is None:
            return None
        try:
            who = await replied.get_sender()
        except Exception:  # noqa: BLE001
            who = None
        name = " ".join(x for x in (getattr(who, "first_name", None), getattr(who, "last_name", None)) if x) or getattr(who, "title", None) or getattr(who, "username", None) or "?"
        return {"kind": media_kind(replied), "who": name, "urls": A.extract_urls(getattr(replied, "message", "") or "")}

    def chat_kind(event) -> str:
        return "private chat" if getattr(event, "is_private", False) else ("group" if getattr(event, "is_group", False) else "channel")

    # ------------------------------------------------------------------ the recent messages (only when the request talks about messages / times / phrases)
    async def recent_rows(event) -> list[dict]:
        """Last messages of the chat as {id, t, who, text} (oldest first): the AI picks the target message by its id, never by guessing."""
        try:
            zone = ZoneInfo(TZ)
        except Exception:  # noqa: BLE001
            zone = None
        today = datetime.now(zone).date()
        rows = []
        try:
            msgs = await client.get_messages(event.chat_id, limit=A.HISTORY_LINES)
        except Exception:  # noqa: BLE001
            return rows
        me = await my_id(client)
        for m in reversed(list(msgs or [])):
            if getattr(m, "action", None) is not None or m.id == getattr(event, "id", None):
                continue
            when = m.date.astimezone(zone) if (zone and m.date) else m.date
            stamp = when.strftime("%H:%M") if when and when.date() == today else (when.strftime("%m-%d %H:%M") if when else "")
            if m.sender_id == me:
                who = "me"
            else:
                snd = getattr(m, "sender", None)
                who = " ".join(x for x in (getattr(snd, "first_name", None), getattr(snd, "last_name", None)) if x) or getattr(snd, "title", None) or getattr(snd, "username", None) or str(m.sender_id or "?")
            text = (getattr(m, "message", "") or "").strip() or f"[{media_kind(m)}]"
            rows.append({"id": m.id, "t": stamp, "who": who, "text": text})
        return rows

    # ------------------------------------------------------------------ planning
    async def run_request(event, request: str, reply_id, rinfo) -> None:
        now = time.monotonic()
        recent = st["times"]
        while recent and now - recent[0] > 60:
            recent.popleft()
        if len(recent) >= A.MAX_REQUESTS_PER_MIN:
            await event.edit(f"⏳ خیلی سریع شد؛ در هر دقیقه حداکثر {A.MAX_REQUESTS_PER_MIN} درخواست. چند ثانیه صبر کن.")
            return
        recent.append(now)
        ask = ask_fn()
        if ask is None:
            await event.edit("❌ ماژول هوش مصنوعی بارگذاری نشده (`.health`).")
            return
        await event.edit("🤖 …")
        undocumented = tuple(sorted(handler_commands() - K.known_commands() - set(A.BLOCKED)))
        rows = await recent_rows(event) if A.wants_history(request) else []
        now_text = datetime.now(ZoneInfo(TZ)).strftime("%Y-%m-%d %H:%M") if rows else ""
        messages = A.build_messages(request, prefix=PREFIX, chat_kind=chat_kind(event), reply_info=rinfo, name=await my_name(client),
                                    extra_commands=undocumented, history=rows or None, now_text=now_text)
        # the answer repeats the user's text inside the JSON: the longer the request, the more room it needs (no character limit on the request)
        out, err = await ask(messages, max_tokens=max(900, min(8000, len(request) // 2 + 1500)), temperature=0.1)
        if not out:
            await event.edit(err)
            return
        plan = A.parse_plan(out, PREFIX, known(), has_reply=bool(reply_id), ids={r["id"] for r in rows})
        if plan is None:
            await event.edit("❌ نتونستم درخواستت رو به دستور تبدیل کنم. یک بار دیگه، واضح‌تر بنویس.")
            return
        await handle_plan(event, request, plan, reply_id)

    def rejected_lines(plan: A.Plan) -> str:
        return "\n".join(f"🚫 `{w}` — {why}" for w, why in plan.rejected[:6])

    async def handle_plan(event, request: str, plan: A.Plan, reply_id) -> None:
        head = f"🤖 {request[:80]}"
        if not plan.actions:
            if plan.clarify:
                text = f"❓ {plan.clarify}\n\n(درخواستت رو کامل‌تر با `{PREFIX}do` دوباره بفرست)"
            else:
                text = plan.reply or "🤷 دستوری برای اجرا پیدا نشد."
            if plan.rejected:
                text += "\n\n" + rejected_lines(plan)
            await publish(client, db, event, head, text, kind="do", question=request[:1500])
            return
        if plan.risky and await danger_on():
            st["pending"][event.chat_id] = {"kind": "plan", "event": event, "request": request, "plan": plan, "reply_id": reply_id,
                                            "expires": time.monotonic() + A.PENDING_TTL}
            lines = "\n".join(f"• `{a.text}`" + ("  ⚠️" if a.risky else "") for a in plan.actions)
            text = (f"{plan.reply}\n\n" if plan.reply else "") + f"⚠️ این دستورها حساس‌اند و فقط با تأیید تو اجرا می‌شن:\n{lines}\n\nبنویس «بله» تا اجرا بشه یا «نه» برای لغو (تا {A.PENDING_TTL // 60} دقیقه)."
            if plan.rejected:
                text += "\n\n" + rejected_lines(plan)
            await publish(client, db, event, head, text, kind="do", question=request[:1500])
            return
        await execute(event, request, plan, reply_id)

    # ------------------------------------------------------------------ making the sent command REALLY run
    ORIGIN_TTL = 600.0
    ORIGIN_TIMEOUT = 8.0

    async def prepare_origin(origin) -> dict:
        """1.19.6: the chat / sender lookups of the fed event are done ONCE per command (and cached for 10 minutes), never once per handler.
        Before, every one of the ~200 command handlers got its own event and each one called get_entity(chat) + get_me() = 2 NETWORK requests,
        i.e. ~400 requests for ONE `.mute` -> Telegram answered with FloodWaits and the command only ran minutes later (typed by hand it was instant)."""
        if origin is None:
            return {}
        cache = client.__dict__.setdefault("_hapoyi_origin_cache", {})
        key = getattr(origin, "chat_id", None)
        hit = cache.get(key)
        now = time.monotonic()
        if hit and now - hit[0] < ORIGIN_TTL:
            return hit[1]
        pre: dict = {}
        for name, meth in (("chat", "get_chat"), ("input_chat", "get_input_chat"), ("sender", "get_sender"), ("input_sender", "get_input_sender")):
            try:
                pre[name] = await asyncio.wait_for(getattr(origin, meth)(), ORIGIN_TIMEOUT)
            except Exception:  # noqa: BLE001  (a missing value is fetched lazily by the handler itself, exactly like for a normal event)
                continue
        if len(pre) == 4:
            cache[key] = (now, pre)
            if len(cache) > 200:
                cache.pop(next(iter(cache)), None)
        return pre

    def make_event(sent, pre, replied, me_id):
        """The event a real update would have produced: same message, chat / sender / input peers already known, and the
        replied message attached (so `event.get_reply_message()` returns the real photo / video / text at once). No network here."""
        ev = events.NewMessage.Event(sent)
        ev._set_client(client)
        m = ev.message
        try:
            if pre.get("chat") is not None and sent.peer_id is not None:
                m._chat = ev._chat = pre["chat"]
                if pre.get("input_chat") is not None:
                    m._input_chat = ev._input_chat = pre["input_chat"]
                if pre.get("sender") is not None:
                    m._sender = pre["sender"]
                    if "_sender" in ev.__dict__:
                        ev.__dict__["_sender"] = pre["sender"]
                if pre.get("input_sender") is not None:
                    m._input_sender = pre["input_sender"]
                    if "_input_sender" in ev.__dict__:
                        ev.__dict__["_input_sender"] = pre["input_sender"]
            if getattr(m, "sender_id", None) is None and me_id:  # a message returned by send_message() has no from_id in private chats
                m.from_id = PeerUser(me_id)
                m._sender_id = me_id
            if replied is not None and getattr(m, "reply_to", None) is not None:
                m._reply_message = replied
        except Exception:  # noqa: BLE001
            log.debug("ai control: event enrichment failed", exc_info=True)
        return ev

    async def feed_handlers(sent, origin=None, replied=None) -> int:
        """Telethon never dispatches the messages this same session sends itself (its own updates are processed but flagged
        `_self_outgoing` = not dispatched). So a command sent with send_message() was just text and no handler ever saw it -
        that is why `.ban` / `.mute` / `.blacklist` typed by the AI did nothing while the same text typed by hand worked.
        Here the sent message is handed to the command handlers like a real update would be: EVERY matching handler gets its OWN
        event (a shared event let the catch-all alias handler overwrite `pattern_match` -> «فرمت اشتباه»)."""
        try:
            handlers = list(client.list_event_handlers())
        except Exception:  # noqa: BLE001
            return 0
        if sent is None or not getattr(sent, "message", None):
            return 0
        try:
            sent.out = True
        except Exception:  # noqa: BLE001
            pass
        matched = []
        pre = await prepare_origin(origin)
        try:
            me_id = await my_id(client)
        except Exception:  # noqa: BLE001
            me_id = None
        for cb, builder in handlers:
            if not isinstance(builder, events.NewMessage) or builder.pattern is None or cb is do_cmd:
                continue
            try:
                if not getattr(builder, "resolved", True):
                    await builder.resolve(client)
                ev = make_event(sent, pre, replied, me_id)
                ok = builder.filter(ev)  # also sets ev.pattern_match to THIS builder's match
                if inspect.isawaitable(ok):
                    ok = await ok
            except Exception:  # noqa: BLE001
                continue
            if ok:
                matched.append((cb, ev))
        if matched:
            task = asyncio.ensure_future(_run_handlers(matched))  # one task per sent command, handlers in order (like one update)
            st["tasks"].add(task)
            task.add_done_callback(st["tasks"].discard)
        return len(matched)

    client._hapoyi_feed_handlers = feed_handlers  # also used by the tests

    async def _run_handlers(matched) -> None:
        for cb, ev in matched:
            try:
                await cb(ev)
            except events.StopPropagation:
                break
            except Exception:  # noqa: BLE001
                log.exception("ai control: command handler %s failed", getattr(cb, "__name__", cb))

    # ------------------------------------------------------------------ doing
    async def execute(event, request: str, plan: A.Plan, reply_id) -> None:
        done: list[str] = []
        failed: list[tuple[str, str]] = []
        st["executing"] = True
        replied_msg = None
        if reply_id:
            try:
                replied_msg = await event.get_reply_message()
            except Exception:  # noqa: BLE001
                replied_msg = None
        try:
            for i, a in enumerate(plan.actions):
                if i:
                    await asyncio.sleep(A.SEND_GAP)
                target = "me" if a.chat == "saved" else event.chat_id
                here = target == event.chat_id
                kw = {"link_preview": False, "parse_mode": None}
                rep_msg = None
                if here and a.reply_id:                      # the message the AI picked from the chat history (by time / phrase / random)
                    kw["reply_to"] = a.reply_id
                    try:
                        rep_msg = await client.get_messages(target, ids=a.reply_id)
                    except Exception:  # noqa: BLE001
                        rep_msg = None
                elif a.on_reply and reply_id and here:
                    kw["reply_to"] = reply_id
                    rep_msg = replied_msg
                try:
                    if a.kind == "text":
                        sent = None
                        for part in A.split_text(a.text):    # no length limit: a long text goes out as several messages
                            sent = await client.send_message(target, part, **kw)
                            st["sent"].append((event.chat_id if target != "me" else None, getattr(sent, "id", None)))
                            kw.pop("reply_to", None)
                    else:
                        sent = await client.send_message(target, a.text, **kw)
                        st["sent"].append((event.chat_id if target != "me" else None, getattr(sent, "id", None)))
                        await feed_handlers(sent, event if here else None, rep_msg)
                    done.append(a.text if len(a.text) <= 100 else a.text[:97] + "…")
                except FloodWaitError as exc:
                    failed.append((a.text, f"FloodWait {getattr(exc, 'seconds', '?')}s — بقیه متوقف شد"))
                    break
                except Exception as exc:  # noqa: BLE001
                    log.warning("ai control: sending %r failed: %s", a.text[:60], exc)
                    failed.append((a.text, exc.__class__.__name__))
        finally:
            await asyncio.sleep(SETTLE)
            st["executing"] = False
        entries = list(await db.get_kv(LOG_KEY, []) or [])
        entries.append({"t": int(time.time()), "req": request[:120], "cmds": [c[:100] for c in done][:8]})
        await db.set_kv(LOG_KEY, entries[-50:])
        lines = [plan.reply or "✅ انجام شد."]
        if done:
            lines.append("▶️ از اکانت تو فرستاده شد:\n" + "\n".join(f"• `{c}`" for c in done))
        if failed:
            lines.append("⚠️ انجام نشد:\n" + "\n".join(f"• `{c}` ({why})" for c, why in failed))
        if plan.rejected:
            lines.append(rejected_lines(plan))
        await publish(client, db, event, f"🤖 {request[:80]}", "\n\n".join(lines), kind="do", question=request[:1500])

    # ------------------------------------------------------------------ .do
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(?:do|act|agent)(?:\s+(.*))?$"))
    async def do_cmd(event):
        request = (event.pattern_match.group(1) or "").strip()
        if not request:
            return await event.reply(USAGE)
        replied = await event.get_reply_message() if event.is_reply else None
        reply_id = getattr(replied, "id", None) if replied is not None else None
        rinfo = await reply_info(replied)
        if not await granted():
            st["pending"][event.chat_id] = {"kind": "grant", "event": event, "request": request, "reply_id": reply_id, "rinfo": rinfo,
                                            "expires": time.monotonic() + A.PENDING_TTL}
            return await event.edit(GRANT_TEXT)
        await run_request(event, request, reply_id, rinfo)

    # ------------------------------------------------------------------ yes / no
    async def resolve(event, yes: bool) -> bool:
        pend = st["pending"].pop(event.chat_id, None)
        if not pend or time.monotonic() > pend["expires"]:
            return False
        origin = pend["event"]
        if not yes:
            try:
                await origin.edit("🚫 لغو شد؛ چیزی اجرا نشد.")
            except Exception:  # noqa: BLE001
                pass
            return True
        if pend["kind"] == "grant":
            await db.set_kv(GRANT_KEY, True)
            await run_request(origin, pend["request"], pend["reply_id"], pend.get("rinfo"))
        else:
            await execute(origin, pend["request"], pend["plan"], pend["reply_id"])
        return True

    @client.on(events.NewMessage(outgoing=True))
    async def confirm_watcher(event):
        """«بله» / «نه» written in the chat where the AI is waiting. Messages the AI itself sent are never taken as an answer."""
        if st["executing"] or not st["pending"]:
            return
        if (event.chat_id, getattr(event, "id", None)) in st["sent"]:
            return
        text = (event.raw_text or "").strip()
        if not text or len(text) > 40 or text.startswith(PREFIX):
            return
        yes, no = A.is_yes(text), A.is_no(text)
        if not (yes or no) or event.chat_id not in st["pending"]:
            return
        if await resolve(event, yes):
            try:
                await event.delete()  # the answer is not conversation: keep the chat clean
            except Exception:  # noqa: BLE001
                pass

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ai\s+(yes|no)$"))
    async def ai_yes_no(event):
        if await resolve(event, event.pattern_match.group(1) == "yes"):
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
            return
        await event.reply("ℹ️ الان چیزی در این گپ منتظر تأیید تو نیست.")

    # ------------------------------------------------------------------ .ai control
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}ai\s+control(?:\s+(on|off|status|log|danger))?(?:\s+(on|off))?$"))
    async def control_cmd(event):
        word, arg = (event.pattern_match.group(1) or "status"), event.pattern_match.group(2)
        if word == "on":
            await db.set_kv(GRANT_KEY, True)
            return await event.reply(f"🔓 کنترل اکانت برای AI روشن شد. با `{PREFIX}do درخواستت` استفاده کن؛ خاموش: `{PREFIX}ai control off`.")
        if word == "off":
            await db.set_kv(GRANT_KEY, False)
            st["pending"].clear()
            return await event.reply("🔒 کنترل اکانت برای AI خاموش شد. دفعهٔ بعد که `.do` بزنی دوباره اجازه می‌پرسه (یا `.ai control on`).")
        if word == "danger":
            if arg not in {"on", "off"}:
                return await event.reply(f"فرمت: `{PREFIX}ai control danger on|off`")
            await db.set_kv(DANGER_KEY, arg == "on")
            return await event.reply("🛡 دستورهای حساس " + ("قبل از اجرا «بله» می‌خوان." if arg == "on" else "بدون پرسیدن اجرا می‌شن (پیش‌فرض)."))
        if word == "log":
            entries = list(await db.get_kv(LOG_KEY, []) or [])[-10:]
            if not entries:
                return await event.reply("📜 هنوز AI کاری برای تو انجام نداده.")
            from datetime import datetime
            lines = []
            for e in reversed(entries):
                when = datetime.fromtimestamp(int(e.get("t", 0))).strftime("%m-%d %H:%M")
                lines.append(f"{when} «{e.get('req', '')[:50]}» → " + (" ; ".join(e.get("cmds", [])) or "—"))
            return await event.reply("📜 آخرین کارهای AI:\n" + "\n".join(lines)[:3800])
        on = await granted()
        return await event.reply(
            f"🤖 کنترل اکانت: {'روشن 🔓' if on else 'خاموش 🔒'} | دستورهای حساس: {'با تأیید' if await danger_on() else 'بدون تأیید'}\n"
            f"`{PREFIX}do درخواست` | `{PREFIX}ai control on|off` | `danger on|off` | `log`\n"
            f"همهٔ دستورها قابل اجرا هستن (فقط `{PREFIX}do` داخل `{PREFIX}do` نه).")
