"""Spam / swearing control for a group, set up in one line - by hand or by telling the AI (`.do`) (1.19.0).

    .modai spam on|off           delete spam: invite links, 2+ links, adverts with a link/@channel/number, mass mentions, the same text 3x, message floods
    .modai swear on|off          delete swearing (built-in list + your own words; disguised spellings like «ک.ی.ر» are caught too)
    .modai ai on|off             an AI judge for what the rules let through (messages of 15+ letters, max 8 AI calls a minute per chat; uses your AI quota)
    .modai action delete         only delete (default)
    .modai action mute 1h [after 3]    delete AND mute that long (1h / 1d / forever) once he broke the rule 3 times within 10 minutes
    .modai action ban [1d] [after 3]   delete AND ban
    .modai scope normal|all      normal members only (admins and your whitelist are exempt - default) | everyone
    .modai notice on|off         a short note «پیام X حذف شد (اسپم)» that disappears after 8 seconds
    .modai words add|del|list <word|phrase>      your own swear / spam words
    .modai log [N]               the last things it removed: who, why, what he wrote, what was done  (nothing happens in the dark)
    .modai status | off

Say it in your own words: `.do در این گروه اسپم رو حذف کن ولی فحاشی مهم نیست` -> `.modai spam on` + `.modai swear off`.
The account needs the «Delete Messages» right (and «Ban Users» for mute / ban).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import defaultdict, deque
from datetime import datetime, timezone

from telethon import events
from telethon.errors import RPCError

from core.actions import UnsupportedChat, edit_banned
from core.identity import my_id
from core.permissions import require_group_right, target_is_admin
from services import modcheck as M
from utils.activity import display_name
from utils.rights import ban_rights, mute_rights

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TABLES = (
    "CREATE TABLE IF NOT EXISTS modai_cfg (chat_id INTEGER PRIMARY KEY, spam INTEGER NOT NULL DEFAULT 0, swear INTEGER NOT NULL DEFAULT 0, "
    "ai INTEGER NOT NULL DEFAULT 0, scope TEXT NOT NULL DEFAULT 'normal', action TEXT NOT NULL DEFAULT 'delete', secs INTEGER NOT NULL DEFAULT 0, "
    "strikes INTEGER NOT NULL DEFAULT 1, notice INTEGER NOT NULL DEFAULT 1)",
    "CREATE TABLE IF NOT EXISTS modai_words (chat_id INTEGER NOT NULL, word TEXT NOT NULL, PRIMARY KEY (chat_id, word))",
    "CREATE TABLE IF NOT EXISTS modai_log (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, ts REAL NOT NULL, user_id INTEGER, name TEXT, "
    "kind TEXT, why TEXT, text TEXT, did TEXT)",
    "CREATE TABLE IF NOT EXISTS whitelist (chat_id INTEGER NOT NULL, user_id INTEGER NOT NULL, PRIMARY KEY (chat_id, user_id))",
)
KINDS = {"spam": "اسپم", "swear": "فحاشی", "ai": "AI"}
STRIKE_WINDOW = 600
AI_PER_MIN = 8
AI_MIN_CHARS = 15
_DUR = re.compile(r"^(\d+)(s|m|h|d|w)$", re.I)
_UNIT = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
_FOREVER = {"forever", "همیشه", "دائمی", "دایمی", "perm"}


def parse_action(words: list[str]) -> tuple[str, int, int] | None:
    """['mute','1h','after','3'] -> ('mute', 3600, 3) | ['ban'] -> ('ban', 0, 1) | ['delete'] -> ('delete', 0, 1). None when not understood."""
    w = [x.lower() for x in words]
    if not w:
        return None
    alias = {"delete": "delete", "del": "delete", "حذف": "delete", "mute": "mute", "میوت": "mute", "سکوت": "mute", "ban": "ban", "بن": "ban"}
    action = alias.get(w[0])
    if action is None:
        return None
    strikes = 1
    rest = w[1:]
    if "after" in rest or "بعد" in rest:
        i = rest.index("after") if "after" in rest else rest.index("بعد")
        try:
            strikes = int(rest[i + 1].translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")))
        except (IndexError, ValueError):
            return None
        if not 1 <= strikes <= 20:
            return None
        rest = rest[:i]
    secs = 0
    if rest:
        if rest[0] in _FOREVER:
            secs = 0
        else:
            m = _DUR.match(rest[0].translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")))
            if not m:
                return None
            secs = max(30, int(m.group(1)) * _UNIT[m.group(2).lower()])
    if action == "delete":
        secs = 0
    return action, secs, strikes


def describe(cfg) -> str:
    on = lambda v: "روشن ✅" if v else "خاموش ⭕"  # noqa: E731
    act = {"delete": "فقط حذف", "mute": "حذف + میوت", "ban": "حذف + بن"}[cfg["action"]]
    if cfg["action"] != "delete":
        act += (f" {cfg['secs'] // 60} دقیقه" if cfg["secs"] else " همیشگی") + f" (بعد از {cfg['strikes']} تخلف در ۱۰ دقیقه)"
    return (f"🧹 کنترل اسپم و فحاشی\n• اسپم: {on(cfg['spam'])}\n• فحاشی: {on(cfg['swear'])}\n• قاضی AI: {on(cfg['ai'])}\n• اقدام: {act}\n"
            f"• شامل: {'همه (ادمین‌ها هم)' if cfg['scope'] == 'all' else 'اعضای عادی (ادمین‌ها و وایت‌لیست معاف)'}\n• اعلان کوتاه: {on(cfg['notice'])}")


def setup(client, db):
    st = {"ready": False, "cfg": {}, "words": {}, "strikes": defaultdict(deque), "ai_times": defaultdict(deque), "flood": M.Flood(), "me": 0, "warned": set()}

    async def ensure() -> None:
        if not st["ready"]:
            st["ready"] = True
            for stmt in TABLES:
                await db.execute(stmt)

    async def cfg_of(chat_id: int):
        hit = st["cfg"].get(chat_id)
        if hit and time.monotonic() - hit[0] < 15:
            return hit[1]
        row = await db.fetchone("SELECT * FROM modai_cfg WHERE chat_id=?", (chat_id,))
        row = dict(row) if row else None
        st["cfg"][chat_id] = (time.monotonic(), row)
        return row

    async def words_of(chat_id: int) -> tuple[str, ...]:
        hit = st["words"].get(chat_id)
        if hit and time.monotonic() - hit[0] < 15:
            return hit[1]
        rows = await db.fetchall("SELECT word FROM modai_words WHERE chat_id=?", (chat_id,))
        out = tuple(r["word"] for r in rows)
        st["words"][chat_id] = (time.monotonic(), out)
        return out

    async def change(chat_id: int, **kv) -> dict:
        await db.execute("INSERT INTO modai_cfg(chat_id) VALUES(?) ON CONFLICT(chat_id) DO NOTHING", (chat_id,))
        sets = ", ".join(f"{k}=?" for k in kv)
        await db.execute(f"UPDATE modai_cfg SET {sets} WHERE chat_id=?", (*kv.values(), chat_id))
        st["cfg"].pop(chat_id, None)
        return await cfg_of(chat_id)

    # ------------------------------------------------------------------ the watcher
    async def judge(chat_id: int, event, text: str, cfg: dict, words: tuple[str, ...]) -> tuple[str, str] | None:
        """-> (kind, reason) or None."""
        uid = int(event.sender_id)
        if cfg["spam"]:
            why = M.static_spam(text) or st["flood"].check(chat_id, uid, text)
            if why:
                return "spam", why
        if cfg["swear"]:
            w = M.find_swear(text, words)
            if w:
                return "swear", f"کلمهٔ «{w}»"
        if cfg["ai"] and len(text) >= AI_MIN_CHARS:
            ask = getattr(client, "_hapoyi_ask_ai", None)
            q = st["ai_times"][chat_id]
            now = time.monotonic()
            while q and now - q[0] > 60:
                q.popleft()
            if ask is not None and len(q) < AI_PER_MIN:
                q.append(now)
                try:
                    out, _err = await ask(M.verdict_prompt(text), max_tokens=30, temperature=0)
                except Exception:  # noqa: BLE001
                    out = None
                v = M.ai_verdict(out)
                if (v == "spam" and cfg["spam"]) or (v == "swear" and cfg["swear"]):
                    return "ai", f"قاضی AI: {KINDS[v]}"
        return None

    async def act(chat_id: int, event, kind: str, why: str, text: str, cfg: dict) -> None:
        uid = int(event.sender_id)
        name = ""
        try:
            name = display_name(await event.get_sender())
        except Exception:  # noqa: BLE001
            pass
        did = []
        can_del = (await require_group_right(client, chat_id, "delete_messages", fresh=False)).allowed
        if can_del:
            try:
                await event.delete()
                did.append("حذف")
            except RPCError:
                did.append("حذف نشد")
        else:
            did.append("حق حذف ندارم")
        if cfg["action"] != "delete":
            q = st["strikes"][(chat_id, uid)]
            now = time.monotonic()
            while q and now - q[0] > STRIKE_WINDOW:
                q.popleft()
            q.append(now)
            if len(q) >= int(cfg["strikes"]):
                q.clear()
                if (await require_group_right(client, chat_id, "ban_users", fresh=False)).allowed:
                    try:
                        rights = ban_rights(cfg["secs"] or None) if cfg["action"] == "ban" else mute_rights(cfg["secs"] or None)
                        await edit_banned(client, chat_id, uid, rights)
                        did.append(("بن" if cfg["action"] == "ban" else "میوت") + (f" {cfg['secs'] // 60}د" if cfg["secs"] else " همیشگی"))
                    except (RPCError, UnsupportedChat) as exc:
                        did.append(f"{cfg['action']} نشد ({exc.__class__.__name__})")
                else:
                    did.append("حق Ban ندارم")
        await db.execute("INSERT INTO modai_log(chat_id,ts,user_id,name,kind,why,text,did) VALUES(?,?,?,?,?,?,?,?)",
                         (chat_id, time.time(), uid, name, kind, why, text[:200], " + ".join(did)))
        if cfg["notice"] and can_del:
            try:
                note = await client.send_message(chat_id, f"🧹 پیام {name or 'کاربر'} حذف شد ({why}).")
                await asyncio.sleep(8)
                await client.delete_messages(chat_id, [note.id])
            except Exception:  # noqa: BLE001
                pass

    @client.on(events.NewMessage(incoming=True))
    async def watcher(event):
        try:
            if not event.is_group or event.out or not event.sender_id:
                return
            text = (event.raw_text or "").strip()
            if not text:
                return
            await ensure()
            chat_id = int(event.chat_id)
            cfg = await cfg_of(chat_id)
            if not cfg or not (cfg["spam"] or cfg["swear"]):
                return
            if not st["me"]:
                st["me"] = await my_id(client)
            uid = int(event.sender_id)
            if uid == st["me"]:
                return
            if await db.fetchone("SELECT 1 FROM whitelist WHERE chat_id=? AND user_id=?", (chat_id, uid)):
                return
            if cfg["scope"] != "all" and await target_is_admin(client, chat_id, uid, fresh=False):
                return
            hit = await judge(chat_id, event, text, cfg, await words_of(chat_id))
            if hit:
                await act(chat_id, event, hit[0], hit[1], text, cfg)
        except Exception:  # noqa: BLE001
            log.exception("modai watcher")

    # ------------------------------------------------------------------ the command
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}modai(?:\s+(.*))?$"))
    async def modai_cmd(event):
        await ensure()
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        chat = int(event.chat_id)
        parts = (event.pattern_match.group(1) or "status").split()
        word = parts[0].lower()
        usage = (f"`{PREFIX}modai spam on|off` | `swear on|off` | `ai on|off` | `action delete|mute 1h [after 3]|ban [1d]` | `scope normal|all` | "
                 f"`notice on|off` | `words add|del|list <کلمه>` | `log [N]` | `status` | `off`")
        cfg = await cfg_of(chat)
        if word == "status":
            return await event.reply((describe(cfg) if cfg else "🧹 کنترل اسپم و فحاشی: خاموش") + "\n\n" + usage)
        if word == "log":
            n = 10
            if len(parts) > 1 and parts[1].isdigit():
                n = max(1, min(int(parts[1]), 30))
            rows = await db.fetchall("SELECT * FROM modai_log WHERE chat_id=? ORDER BY id DESC LIMIT ?", (chat, n))
            if not rows:
                return await event.reply("🧹 هنوز چیزی حذف نشده.")
            from zoneinfo import ZoneInfo  # noqa: PLC0415
            tz = ZoneInfo(os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran")
            lines = [f"{datetime.fromtimestamp(r['ts'], timezone.utc).astimezone(tz).strftime('%m-%d %H:%M')} • {r['name'] or r['user_id']} • "
                     f"{r['why']} → {r['did']}\n   «{(r['text'] or '')[:60]}»" for r in rows]
            return await event.reply("🧾 آخرین موارد:\n" + "\n".join(lines))
        if word == "words":
            sub = parts[1].lower() if len(parts) > 1 else "list"
            w = " ".join(parts[2:]).strip()
            if sub == "list":
                rows = await db.fetchall("SELECT word FROM modai_words WHERE chat_id=?", (chat,))
                return await event.reply("🔤 کلمه‌های تو: " + (" ، ".join(r["word"] for r in rows) if rows else "—") + "\n(کلمه‌های پیش‌فرض هم فعال‌اند)")
            if sub in {"add", "del"} and w:
                if sub == "add":
                    await db.execute("INSERT OR IGNORE INTO modai_words(chat_id,word) VALUES(?,?)", (chat, w.lower()))
                else:
                    await db.execute("DELETE FROM modai_words WHERE chat_id=? AND word=?", (chat, w.lower()))
                st["words"].pop(chat, None)
                return await event.reply(("✅ اضافه شد: " if sub == "add" else "✅ حذف شد: ") + w)
            return await event.reply(f"فرمت: `{PREFIX}modai words add|del|list <کلمه>`")
        p = await require_group_right(client, chat, "delete_messages")
        if not p.allowed:
            return await event.reply("❌ برای این کار باید حق Delete Messages داشته باشی: " + p.reason)
        if word == "off":
            await change(chat, spam=0, swear=0, ai=0)
            return await event.reply("🧹 کنترل اسپم و فحاشی خاموش شد.")
        arg = parts[1].lower() if len(parts) > 1 else ""
        if word in {"spam", "swear", "ai", "notice"} and arg in {"on", "off"}:
            new = await change(chat, **{word: 1 if arg == "on" else 0})
            extra = "\n⚠️ قاضی AI از سهمیهٔ AI تو مصرف می‌کند." if word == "ai" and arg == "on" else ""
            return await event.reply(describe(new) + extra)
        if word == "scope" and arg in {"normal", "all"}:
            return await event.reply(describe(await change(chat, scope=arg)))
        if word == "action":
            parsed = parse_action(parts[1:])
            if parsed is None:
                return await event.reply(f"❌ مثال: `{PREFIX}modai action delete` | `action mute 1h after 3` | `action ban 1d` | `action mute forever`")
            if parsed[0] != "delete":
                bp = await require_group_right(client, chat, "ban_users")
                if not bp.allowed:
                    return await event.reply("❌ برای میوت/بن باید حق Ban Users داشته باشی: " + bp.reason)
            return await event.reply(describe(await change(chat, action=parsed[0], secs=parsed[1], strikes=parsed[2])))
        await event.reply("❌ فرمت نامعتبر.\n" + usage)
