"""Scheduled messages and polls with a clock time, a reply target and an automatic pin (1.19.0).

    .sched <when> [pin] [silent] <text>                 a text, sent by Telegram itself at that time (works even if the self is offline)
    .sched <when> [pin] poll [multi] [public] Q | A | B  a poll
    .sched list | del <id|all>                          the scheduled ones of this chat

    <when>  10m | 2h | 17:30 | ساعت 17 | فردا 09:00 | 2026-11-02 18:00      (Asia/Tehran unless TIMEZONE is set)
    Reply on a message -> the scheduled text/poll is sent as a reply to it.   `pin` pins it as soon as it is sent (needs the Pin right).
`.poll` also takes `pin` now (pins the poll at once).
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime, timezone

from telethon import events, types
from telethon.errors import RPCError
from telethon.tl.functions.messages import DeleteScheduledMessagesRequest

from core.identity import my_id
from core.permissions import explain_error, reply_to_id, require_group_right
from services import schedparse as S

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
TABLE = ("CREATE TABLE IF NOT EXISTS sched_pins (id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL, due REAL NOT NULL, kind TEXT NOT NULL, "
         "text TEXT NOT NULL DEFAULT '')")
GIVE_UP = 600     # seconds after the due time the pin job keeps looking for the sent message


def build_poll(question: str, options: list[str], multi: bool, public: bool):
    answers = [types.PollAnswer(text=types.TextWithEntities(text=o, entities=[]), option=bytes([i])) for i, o in enumerate(options)]
    poll = types.Poll(id=0, question=types.TextWithEntities(text=question, entities=[]), answers=answers, hash=0,
                      multiple_choice=multi or None, public_voters=public or None)
    return types.InputMediaPoll(poll=poll)


def check_poll(raw: str) -> tuple[str, list[str]] | str:
    parts = [x.strip() for x in re.split(r"\||\n", raw) if x.strip()]
    if len(parts) < 3:
        return "فرمت نظرسنجی: سؤال | گزینه ۱ | گزینه ۲ (۲ تا ۱۰ گزینه)"
    q, opts = parts[0], parts[1:]
    if len(opts) > 10:
        return "حداکثر ۱۰ گزینه."
    if len(q) > 255 or any(len(o) > 100 for o in opts):
        return "سؤال حداکثر ۲۵۵ و هر گزینه حداکثر ۱۰۰ حرف."
    if len(set(opts)) != len(opts):
        return "گزینه‌ها نباید تکراری باشند."
    return q, opts


def setup(client, db):
    state = {"ready": False, "task": None}

    async def ensure() -> None:
        if state["ready"]:
            return
        state["ready"] = True
        await db.execute(TABLE)
        try:
            state["task"] = asyncio.get_running_loop().create_task(pin_loop())
        except RuntimeError:
            pass

    async def pin_loop() -> None:
        while True:
            try:
                await asyncio.sleep(8)
                await pin_due()
            except asyncio.CancelledError:
                return
            except Exception:  # noqa: BLE001
                log.exception("sched pin loop")

    async def pin_due() -> None:
        now = time.time()
        for row in await db.fetchall("SELECT * FROM sched_pins WHERE due<=?", (now,)):
            if now > row["due"] + GIVE_UP:
                await db.execute("DELETE FROM sched_pins WHERE id=?", (row["id"],))
                continue
            found = None
            try:
                async for m in client.iter_messages(row["chat_id"], from_user="me", limit=25):
                    if m.date.timestamp() < row["due"] - 20:
                        break
                    same = bool(getattr(m, "poll", None)) if row["kind"] == "poll" else (m.raw_text or "").strip() == row["text"].strip()
                    if same:
                        found = m
                        break
            except Exception:  # noqa: BLE001
                continue
            if found is not None:
                try:
                    await client.pin_message(row["chat_id"], found.id)
                except RPCError as exc:
                    log.info("scheduled pin failed: %s", exc.__class__.__name__)
                await db.execute("DELETE FROM sched_pins WHERE id=?", (row["id"],))

    client._hapoyi_sched_pin_due = pin_due   # one round of the pin job (also used by the tests)

    def local(ts: datetime) -> str:
        from zoneinfo import ZoneInfo  # noqa: PLC0415
        return ts.astimezone(ZoneInfo(TZ)).strftime("%Y-%m-%d %H:%M")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}sched(?:\s+(.*))?$"))
    async def sched_cmd(event):
        await ensure()
        raw = (event.pattern_match.group(1) or "").strip()
        usage = (f"فرمت: `{PREFIX}sched 17:30 [pin] متن` | `{PREFIX}sched فردا 09:00 poll سؤال | الف | ب` | `{PREFIX}sched 10m pin ...`\n"
                 f"زمان: `10m` `2h` `17:30` `فردا 09:00` `2026-11-02 18:00` • Reply = ریپلای می‌شود • `{PREFIX}sched list|del <id|all>`")
        if not raw:
            return await event.reply(usage)
        head, _, rest = raw.partition(" ")
        word = head.lower()
        if word == "list":
            rows = []
            async for m in client.iter_messages(event.chat_id, scheduled=True, limit=50):
                rows.append(f"#{m.id} — {local(m.date)} — {('📊 نظرسنجی' if getattr(m, 'poll', None) else (m.raw_text or '[مدیا]')[:50])}")
            return await event.reply("🕒 زمان‌بندی‌شده‌ها\n" + "\n".join(rows) if rows else "🕒 پیام زمان‌بندی‌شده‌ای نیست.")
        if word in {"del", "delete", "cancel"}:
            which = rest.strip().lstrip("#").lower()
            if which == "all":
                ids = [m.id async for m in client.iter_messages(event.chat_id, scheduled=True, limit=100)]
            elif which.isdigit():
                ids = [int(which)]
            else:
                return await event.reply("❌ شمارهٔ پیام یا all بده.")
            if not ids:
                return await event.reply("ℹ️ چیزی برای حذف نبود.")
            try:
                await client(DeleteScheduledMessagesRequest(peer=await client.get_input_entity(event.chat_id), id=ids))
            except RPCError as exc:
                return await event.reply(f"❌ حذف نشد: {explain_error(exc)}")
            return await event.reply(f"✅ {len(ids)} مورد حذف شد.")
        try:
            when, words = S.parse_when(raw.split(), TZ)
        except S.WhenError as exc:
            return await event.reply(f"❌ {exc}\n\n{usage}")
        opts, text = S.parse_options(words)
        if not text.strip():
            return await event.reply("❌ متن (یا سؤال نظرسنجی) را هم بنویس.\n\n" + usage)
        if opts["pin"] and event.is_group:
            p = await require_group_right(client, event.chat_id, "pin_messages")
            if not p.allowed:
                return await event.reply("❌ برای پین باید حق Pin Messages داشته باشی: " + p.reason)
        kw = {"schedule": when, "reply_to": reply_to_id(event), "silent": opts["silent"] or None}
        try:
            if opts["poll"]:
                parsed = check_poll(text)
                if isinstance(parsed, str):
                    return await event.reply("❌ " + parsed)
                await client.send_file(event.chat_id, build_poll(parsed[0], parsed[1], opts["multi"], opts["public"]), **kw)
            else:
                await client.send_message(event.chat_id, text.strip(), link_preview=False, **kw)
        except RPCError as exc:
            return await event.reply(f"❌ زمان‌بندی نشد: {explain_error(exc)}")
        if opts["pin"]:
            await db.execute("INSERT INTO sched_pins(chat_id,due,kind,text) VALUES(?,?,?,?)",
                             (event.chat_id, when.timestamp(), "poll" if opts["poll"] else "text", "" if opts["poll"] else text.strip()))
        extra = " + پین" if opts["pin"] else ""
        await event.reply(f"🕒 {'نظرسنجی' if opts['poll'] else 'پیام'} برای {local(when)} ({TZ}) زمان‌بندی شد{extra}.")
