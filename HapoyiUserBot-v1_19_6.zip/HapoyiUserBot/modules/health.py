"""`.health` - account health panel, `.modules` - module list.

    .health          this account: uptime, modules (failed ones named), pacing stats, last handler errors, database
    .health all      (owner/main account only) every running account of the fleet
"""
from __future__ import annotations

import os
import re
import time
from datetime import datetime

from telethon import events

PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)


def fmt_age(seconds: float) -> str:
    s = int(max(0, seconds))
    d, r = divmod(s, 86400)
    h, r = divmod(r, 3600)
    m, _ = divmod(r, 60)
    return " ".join(x for x in (f"{d}d" if d else "", f"{h}h" if h else "", f"{m}m") if x)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}health(?:\s+(all))?$"))
    async def health(event):
        registry = getattr(client, "_hapoyi_registry", None)
        if event.pattern_match.group(1):
            fleet = getattr(client, "_hapoyi_fleet", None)
            if fleet is None or getattr(client, "_hapoyi_kind", "") != "main":
                return await event.reply("❌ `.health all` فقط روی اکانت اصلی (مالک) کار می‌کند.")
            lines = [f"🩺 اکانت‌های روشن: {len(fleet.runtimes)}"]
            for rt in fleet.runtimes.values():
                pacer = getattr(rt.client, "_hapoyi_pacer", None)
                errs = len(getattr(rt.client, "_hapoyi_errors", ()) or ())
                lines.append(f"• #{rt.account_id} {rt.label} ({rt.kind}) — {fmt_age(time.time() - rt.started_at)} | خطا: {errs}"
                             + (f" | FloodWait: {pacer.flood_waits}" if pacer and pacer.flood_waits else ""))
            return await event.reply("\n".join(lines)[:3900])
        started = getattr(client, "_hapoyi_started", None)
        lines = ["🩺 Hāpoyi Health", f"uptime: {fmt_age(time.time() - started) if started else '?'}"]
        if registry:
            failed = [(n, i.error) for n, i in registry.modules.items() if i.error]
            lines.append(f"{registry.summary()}")
            lines += [f"  ❌ {n}: {e}" for n, e in failed[:6]]
        pacer = getattr(client, "_hapoyi_pacer", None)
        if pacer is not None:
            lines.append(f"pacing: {pacer.delayed} ارسال/ادیت تأخیر خورد ({pacer.delay_total:.0f}s) | FloodWait تلگرام: {pacer.flood_waits}")
        errs = list(getattr(client, "_hapoyi_errors", ()) or ())
        if errs:
            lines.append("آخرین خطاها:")
            lines += [f"  {datetime.fromtimestamp(t).strftime('%H:%M:%S')} {w}: {m}" for t, w, m in errs[-5:]]
        else:
            lines.append("خطای handler: ندارد ✅")
        try:
            size = os.path.getsize(db.path) / 1024
            lines.append(f"database: ok ({size:.0f} KB)")
        except OSError:
            lines.append("database: ok")
        await event.reply("\n".join(lines)[:3900])

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}modules$"))
    async def modules_cmd(event):
        registry = getattr(client, "_hapoyi_registry", None)
        if registry is None:
            return await event.reply("ℹ️ اطلاعات ماژول‌ها در دسترس نیست.")
        lines = ["🧩 Modules"]
        for name, info in sorted(registry.modules.items()):
            status = "✅" if info.loaded else "❌"
            lines.append(f"{status} {name}")
        await event.reply("\n".join(lines)[:4000])
