"""Button panels for the `.menu` UI: friends/enemies, group (welcome / leave / LinkGuard / locks / slow-mode),
security (AutoBan / Safety Guard / Account Protect status) and automation.

Every text command keeps working - these panels are an *additional* way to do the same things. All settings are
read from / written to the clicking owner's OWN account database (`rt.db`) or applied through that account's client.
Chat-scoped panels act on the chat the menu was opened in (`.menu` remembers it; for menus opened with a bare
`@YourBot` the chat is unknown, and the panel says so).
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from telethon import Button, types
from telethon.errors import RPCError
from telethon.tl.functions.channels import GetFullChannelRequest, ToggleSlowModeRequest
from telethon.tl.functions.messages import EditChatDefaultBannedRightsRequest

from core.identity import my_id
from core.permissions import explain_error, require_group_right
from modules.extras import LOCK_LABELS, LOCK_TYPES, SLOW_VALUES, _RIGHT_FIELDS

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

# `.menu` remembers where it was opened:  owner user id -> chat id
CHAT_CTX: dict[int, int] = {}

LOCK_BUTTONS = (("msg", "💬 پیام"), ("media", "🖼 مدیا"), ("stickers", "🙂 استیکر"), ("gifs", "🎞 گیف"), ("links", "🔗 لینک"),
                ("polls", "📊 نظرسنجی"), ("invite", "➕ افزودن"), ("pin", "📌 پین"), ("info", "ℹ️ اطلاعات"))
LINK_ACTIONS = ("delete", "warn", "mute", "ban")
SLOW_LABEL = {0: "خاموش", 10: "10s", 30: "30s", 60: "1m", 300: "5m", 900: "15m", 3600: "1h"}


def _e(text: Any) -> str:
    import html

    return html.escape(str(text))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _nav(extra: list | None = None):
    return (extra or []) + [[Button.inline("⬅️ منو", b"ui:home"), Button.inline("⚡ اکشن‌ها", b"ui:act")]]


# ====================================================================== friends / enemies
async def _label(client, uid: int) -> str:
    try:
        ent = await client.get_entity(uid)
        name = " ".join(x for x in (getattr(ent, "first_name", None), getattr(ent, "last_name", None)) if x) or getattr(ent, "title", None)
        user = getattr(ent, "username", None)
        return (name or str(uid)) + (f" @{user}" if user else "")
    except Exception:  # noqa: BLE001
        return str(uid)


async def relations_panel(event, rt, data: str) -> None:
    db, client = rt.db, rt.client
    owner = await my_id(client)
    parts = data.split(":")  # ui:p:rel[:action[:arg[:arg2]]]
    note = ""
    if len(parts) >= 4:
        action = parts[3]
        if action == "t" and len(parts) == 5:
            await db.execute("UPDATE relations SET enabled=1-enabled,updated_at=? WHERE owner_id=? AND user_id=?", (_now(), owner, int(parts[4])))
        elif action == "d" and len(parts) == 5:
            await db.execute("DELETE FROM relations WHERE owner_id=? AND user_id=?", (owner, int(parts[4])))
            note = "🗑 حذف شد."
        elif action == "all" and len(parts) == 6 and parts[4] in ("friend", "enemy"):
            await db.execute("UPDATE relations SET enabled=?,updated_at=? WHERE owner_id=? AND kind=?", (1 if parts[5] == "on" else 0, _now(), owner, parts[4]))
        elif action == "clr" and len(parts) == 5 and parts[4] in ("friend", "enemy"):
            await db.execute("DELETE FROM relations WHERE owner_id=? AND kind=?", (owner, parts[4]))
            note = "🗑 لیست خالی شد."
    lines = ["<b>🤝 دوست / دشمن</b>"]
    rows_btn: list = []
    for kind, icon, title in (("friend", "❤️", "دوست‌ها"), ("enemy", "😈", "دشمن‌ها")):
        rows = await db.fetchall("SELECT user_id,enabled FROM relations WHERE owner_id=? AND kind=? ORDER BY updated_at DESC LIMIT 8", (owner, kind))
        total = (await db.fetchone("SELECT COUNT(*) AS n FROM relations WHERE owner_id=? AND kind=?", (owner, kind)))["n"]
        lines.append(f"\n{icon} <b>{title}</b> ({total})")
        if not rows:
            lines.append("  خالی")
        for r in rows:
            lines.append(f"  {'🟢' if r['enabled'] else '⏸'} {_e(await _label(client, int(r['user_id'])))}")
            rows_btn.append([Button.inline(f"{'⏸' if r['enabled'] else '▶️'} {icon}", f"ui:p:rel:t:{r['user_id']}".encode()),
                             Button.inline(f"🗑 {icon} {str(r['user_id'])[-6:]}", f"ui:p:rel:d:{r['user_id']}".encode())])
        if total:
            rows_btn.append([Button.inline(f"▶️ همهٔ {title}", f"ui:p:rel:all:{kind}:on".encode()),
                             Button.inline(f"⏸ همهٔ {title}", f"ui:p:rel:all:{kind}:off".encode()),
                             Button.inline("🧹 خالی", f"ui:p:rel:clr:{kind}".encode())])
    lines.append(f"\nافزودن: روی پیام فرد Reply کن و <code>{PREFIX}friend add</code> یا <code>{PREFIX}enemy add</code> بزن (دکمه نمی‌تونه کاربر را انتخاب کند).")
    if note:
        lines.insert(1, note)
    await event.edit("\n".join(lines)[:3900], parse_mode="html", buttons=_nav(rows_btn))


# ====================================================================== group / security panels
def _target_chat(event) -> int | None:
    return event.chat_id or CHAT_CTX.get(int(event.sender_id))


async def _need(event, rt, chat_id: int, right: str) -> bool:
    perm = await require_group_right(rt.client, chat_id, right)
    if not perm.allowed:
        await event.answer("❌ " + perm.reason, alert=True)
        return False
    return True


async def group_panel(event, rt, data: str, mode: str = "grp") -> None:
    db, client = rt.db, rt.client
    chat_id = _target_chat(event)
    if not chat_id:
        return await event.edit("<b>⚠️ چت هدف مشخص نیست</b>\n\nاین پنل روی یک گروه کار می‌کند. <code>.menu</code> را داخل همان گروه بفرست.",
                                parse_mode="html", buttons=_nav())
    if chat_id > 0:
        return await event.edit("<b>⚠️ این چت گروه نیست</b>\n\nپنل گروه فقط برای گروه/سوپرگروه است؛ <code>.menu</code> را داخل گروه بفرست.",
                                parse_mode="html", buttons=_nav())
    parts = data.split(":")  # ui:p:g|sec[:action[:arg]]
    action = parts[3] if len(parts) > 3 else ""
    arg = parts[4] if len(parts) > 4 else ""
    cfg = await db.get_chat_settings(chat_id)
    try:
        if action == "w":
            if await _need(event, rt, chat_id, "change_info"):
                on = not cfg.get("welcome_enabled", False)
                await db.update_chat_settings(chat_id, welcome_enabled=on, welcome_text=cfg.get("welcome_text") or "👋 خوش اومدی {mention} به {chat}!")
        elif action == "lv":
            if await _need(event, rt, chat_id, "change_info"):
                await db.update_chat_settings(chat_id, leave_enabled=not cfg.get("leave_enabled", False))
        elif action == "lg":
            if await _need(event, rt, chat_id, "delete_messages"):
                on = not cfg.get("linkguard_enabled", False)
                await db.update_chat_settings(chat_id, linkguard_enabled=on, linkguard_action=cfg.get("linkguard_action", "delete"),
                                              linkguard_mode=cfg.get("linkguard_mode", "all"), linkguard_duration=int(cfg.get("linkguard_duration", 600) or 600),
                                              linkguard_threshold=int(cfg.get("linkguard_threshold", 1) or 1), linkguard_window=int(cfg.get("linkguard_window", 60) or 60))
        elif action == "la":
            cur = str(cfg.get("linkguard_action", "delete"))
            nxt = LINK_ACTIONS[(LINK_ACTIONS.index(cur) + 1) % 4] if cur in LINK_ACTIONS else "delete"
            if nxt in ("mute", "ban") and not await _need(event, rt, chat_id, "ban_users"):
                nxt = "delete" if cur != "delete" else "warn"
            await db.update_chat_settings(chat_id, linkguard_action=nxt)
        elif action == "ls":
            await db.update_chat_settings(chat_id, linkguard_scope="all" if cfg.get("linkguard_scope", "normal") == "normal" else "normal")
        elif action == "ab":
            if await _need(event, rt, chat_id, "ban_users"):
                row = await db.fetchone("SELECT enabled,action FROM autoban WHERE chat_id=?", (chat_id,))
                new = 0 if row and row["enabled"] else 1
                await db.execute("INSERT INTO autoban(chat_id,enabled,action,updated_at) VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET enabled=excluded.enabled,updated_at=excluded.updated_at",
                                 (chat_id, new, (row["action"] if row else "ban"), _now()))
        elif action == "aa":
            row = await db.fetchone("SELECT enabled,action FROM autoban WHERE chat_id=?", (chat_id,))
            cur = row["action"] if row else "ban"
            nxt = {"ban": "mute", "mute": "delete", "delete": "ban"}.get(cur, "ban")
            if await _need(event, rt, chat_id, "ban_users"):
                await db.execute("INSERT INTO autoban(chat_id,enabled,action,updated_at) VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET action=excluded.action,updated_at=excluded.updated_at",
                                 (chat_id, int(row["enabled"]) if row else 0, nxt, _now()))
        elif action == "sg":
            await db.update_chat_settings(chat_id, safety_guard=not cfg.get("safety_guard", True))
        elif action == "k" and arg in LOCK_TYPES:
            if await _need(event, rt, chat_id, "ban_users"):
                chat = await client.get_entity(chat_id)
                current = getattr(chat, "default_banned_rights", None)
                flags = {name: bool(getattr(current, name, False)) for name in _RIGHT_FIELDS}
                field = LOCK_TYPES[arg][0]
                flags[field] = not flags.get(field, False)
                await client(EditChatDefaultBannedRightsRequest(peer=await client.get_input_entity(chat_id), banned_rights=types.ChatBannedRights(until_date=None, **flags)))
        elif action == "sm" and arg.isdigit() and int(arg) in SLOW_VALUES:
            if await _need(event, rt, chat_id, "change_info"):
                peer = await client.get_input_entity(chat_id)
                if not isinstance(peer, types.InputPeerChannel):
                    await event.answer("❌ حالت آهسته فقط در سوپرگروه‌هاست.", alert=True)
                else:
                    await client(ToggleSlowModeRequest(types.InputChannel(peer.channel_id, peer.access_hash), int(arg)))
    except RPCError as exc:
        await event.answer("❌ " + explain_error(exc), alert=True)
    except Exception as exc:  # noqa: BLE001
        log.warning("group panel action failed: %s: %s", exc.__class__.__name__, exc)
        await event.answer(f"❌ {exc.__class__.__name__}", alert=True)

    # ---- render fresh state
    cfg = await db.get_chat_settings(chat_id)
    ab = await db.fetchone("SELECT enabled,action FROM autoban WHERE chat_id=?", (chat_id,))
    try:
        chat = await client.get_entity(chat_id)
        title = getattr(chat, "title", None) or str(chat_id)
        rights = getattr(chat, "default_banned_rights", None)
    except Exception:  # noqa: BLE001
        title, rights = str(chat_id), None
    slow = None
    try:
        peer = await client.get_input_entity(chat_id)
        if isinstance(peer, types.InputPeerChannel):
            full = await client(GetFullChannelRequest(types.InputChannel(peer.channel_id, peer.access_hash)))
            slow = int(getattr(full.full_chat, "slowmode_seconds", 0) or 0)
    except Exception:  # noqa: BLE001
        slow = None

    def on(v: bool) -> str:
        return "🟢" if v else "⚪️"

    lg_on, ab_on = bool(cfg.get("linkguard_enabled", False)), bool(ab and ab["enabled"])
    sg_on = bool(cfg.get("safety_guard", True))
    base = "ui:p:" + ("sec" if mode == "sec" else "g")
    lines = [f"<b>{'🔐 پنل امنیت' if mode == 'sec' else '🛡 پنل گروه'}</b> — {_e(title)}", ""]
    btn: list = []
    if mode == "grp":
        lines += [f"{on(cfg.get('welcome_enabled', False))} خوش‌آمد   {on(cfg.get('leave_enabled', False))} ثبت خروج"]
        btn.append([Button.inline(f"{on(cfg.get('welcome_enabled', False))} Welcome", f"{base}:w".encode()),
                    Button.inline(f"{on(cfg.get('leave_enabled', False))} Leave log", f"{base}:lv".encode())])
    lines += [f"{on(lg_on)} LinkGuard: {cfg.get('linkguard_action', 'delete')} / scope={cfg.get('linkguard_scope', 'normal')}",
              f"{on(ab_on)} AutoBan: {ab['action'] if ab else 'ban'}", f"{on(sg_on)} Safety Guard"]
    btn.append([Button.inline(f"{on(lg_on)} LinkGuard", f"{base}:lg".encode()), Button.inline(f"🔁 {cfg.get('linkguard_action', 'delete')}", f"{base}:la".encode()),
                Button.inline(f"👥 {cfg.get('linkguard_scope', 'normal')}", f"{base}:ls".encode())])
    btn.append([Button.inline(f"{on(ab_on)} AutoBan", f"{base}:ab".encode()), Button.inline(f"🔁 {ab['action'] if ab else 'ban'}", f"{base}:aa".encode()),
                Button.inline(f"{on(sg_on)} Safety", f"{base}:sg".encode())])
    if mode == "grp":
        lines.append("\n🔒 قفل‌ها (روی همهٔ اعضا):")
        row: list = []
        for key, label in LOCK_BUTTONS:
            locked = bool(getattr(rights, LOCK_TYPES[key][0], False)) if rights is not None else False
            row.append(Button.inline(f"{'🔒' if locked else '🔓'} {label}", f"{base}:k:{key}".encode()))
            if len(row) == 3:
                btn.append(row)
                row = []
        if row:
            btn.append(row)
        if slow is not None:
            lines.append(f"🐢 حالت آهسته: {SLOW_LABEL.get(slow, str(slow) + 's')}")
            btn.append([Button.inline(("• " if slow == v else "") + SLOW_LABEL[v], f"{base}:sm:{v}".encode()) for v in (0, 10, 30, 60)])
            btn.append([Button.inline(("• " if slow == v else "") + SLOW_LABEL[v], f"{base}:sm:{v}".encode()) for v in (300, 900, 3600)])
    else:
        prot = await db.get_kv("account_protect", {}) or {}
        lines.append(f"\n🛡 Account Protect: {'🟢 روشن' if prot.get('enabled') else '⚪️ خاموش'} (بستن سشن‌های جدید: {int(prot.get('killed', 0))})")
        lines.append(f"روشن/خاموش‌کردنش با <code>{PREFIX}protect on|off</code> (سشن‌ها را اسنپ‌شات می‌کند، برای همین دستوری می‌مونه).")
        btn.append([Button.inline("🛡 پنل کامل گروه", b"ui:p:g")])
    lines.append("\nتنظیمات برای همین گروه ذخیره می‌شن؛ همهٔ دستورهای متنی هم کار می‌کنن.")
    await event.edit("\n".join(lines)[:3900], parse_mode="html", buttons=_nav(btn))


# ====================================================================== automation / message lifecycle
async def automation_panel(event, rt, data: str) -> None:
    db, client = rt.db, rt.client
    parts = data.split(":")
    if len(parts) > 3 and parts[3] == "dj":
        if len(parts) > 4 and parts[4] == "clear":
            await db.execute("DELETE FROM delete_jobs")
        if len(parts) > 4 and parts[4] == "d" and len(parts) > 5:
            await db.execute("DELETE FROM delete_jobs WHERE id=?", (int(parts[5]),))
        return await _delete_jobs(event, db)
    uid = await my_id(client)
    afk = await db.fetchone("SELECT 1 FROM afk WHERE owner_id=? AND enabled=1", (uid,))
    n = lambda sql: db.fetchone(sql)  # noqa: E731
    every = (await n("SELECT COUNT(*) AS n FROM repeat_jobs WHERE enabled=1"))["n"]
    ar = (await n("SELECT COUNT(*) AS n FROM autoreplies WHERE enabled=1"))["n"]
    dj = (await n("SELECT COUNT(*) AS n FROM delete_jobs"))["n"]
    pr = (await n("SELECT COUNT(*) AS n FROM price_alerts WHERE enabled=1"))["n"]
    text = ("<b>⏰ اتوماسیون</b>\n\n"
            f"🌙 AFK: {'🟢 روشن' if afk else '⚪️ خاموش'}\n🔁 every فعال: {every}\n🤖 AutoReply فعال: {ar}\n"
            f"⏳ حذف‌های زمان‌بندی‌شده: {dj}\n💱 هشدار قیمت فعال: {pr}\n\n"
            f"ساخت مورد جدید با دستور متنی است (مثلاً <code>{PREFIX}every 10m 5 سلام</code>)؛ مدیریت موارد موجود با دکمه‌ها.")
    btn = [[Button.inline("🌙 AFK روشن/خاموش", b"ui:afk")],
           [Button.inline("🔁 مدیریت every", b"ui:ev"), Button.inline("🤖 AutoReply", b"ui:ar")],
           [Button.inline("⏳ حذف‌های زمان‌بندی‌شده", b"ui:p:auto:dj")]]
    await event.edit(text, parse_mode="html", buttons=_nav(btn))


async def _delete_jobs(event, db) -> None:
    rows = await db.fetchall("SELECT id,chat_id,run_at,kind,preview FROM delete_jobs ORDER BY run_at LIMIT 10")
    if not rows:
        return await event.edit("<b>⏳ حذف‌های زمان‌بندی‌شده</b>\n\nچیزی در صف نیست.", parse_mode="html", buttons=_nav([[Button.inline("⬅️ اتوماسیون", b"ui:p:auto")]]))
    lines, btn = ["<b>⏳ حذف‌های زمان‌بندی‌شده</b>", ""], []
    for r in rows:
        left = max(0, int(r["run_at"] - time.time()))
        lines.append(f"#{r['id']} {_e(r['kind'])} • چت {r['chat_id']} • {left}s دیگر\n   «{_e((r['preview'] or '')[:30])}»")
        btn.append([Button.inline(f"🗑 لغو #{r['id']}", f"ui:p:auto:dj:d:{r['id']}".encode())])
    btn.append([Button.inline("🧹 لغو همه", b"ui:p:auto:dj:clear"), Button.inline("⬅️ اتوماسیون", b"ui:p:auto")])
    await event.edit("\n".join(lines)[:3900], parse_mode="html", buttons=_nav(btn))


# ====================================================================== media helper
async def media_panel(event, rt, data: str) -> None:
    from utils import tmpclean

    note = ""
    if data.endswith(":clean"):
        removed, freed = tmpclean.sweep_all(600)  # idle for 10+ minutes; running downloads are never touched
        note = f"🧹 {removed} مورد موقت پاک شد ({freed / 1048576:.1f} MB).\n\n"
    size = sum(tmpclean.usage().values())
    text = (f"<b>🎞️ مدیا</b>\n\n{note}"
            f"💾 فایل‌های موقت روی سرور: {size / 1048576:.1f} MB\n\n"
            "ابزارهای مدیا روی یک پیام Reply می‌شن، پس دکمه نمی‌تونه جایگزینشون بشه:\n"
            f"• <code>{PREFIX}download</code> / <code>دانلود</code> → Saved Messages\n"
            f"• <code>{PREFIX}ss</code> / <code>اسکرین</code> → استیکر اسکرین‌شات\n"
            f"• <code>{PREFIX}sticker</code> ، <code>{PREFIX}gif</code> ، <code>{PREFIX}resize</code> ، <code>{PREFIX}watermark</code> ، <code>{PREFIX}rename</code>")
    await event.edit(text, parse_mode="html", buttons=_nav([[Button.inline("🧹 پاک‌سازی فایل‌های موقت (بیش از ۱۰ دقیقه)", b"ui:p:media:clean")]]))


async def handle(event, rt, data: str) -> bool:
    if data.startswith("ui:p:rel"):
        await relations_panel(event, rt, data)
    elif data.startswith("ui:p:g"):
        await group_panel(event, rt, data, "grp")
    elif data.startswith("ui:p:sec"):
        await group_panel(event, rt, data, "sec")
    elif data.startswith("ui:p:auto"):
        await automation_panel(event, rt, data)
    elif data.startswith("ui:p:media"):
        await media_panel(event, rt, data)
    elif data.startswith("ui:p:mdl"):
        from modules import ai_models

        await ai_models.panel(event, rt, data)
    else:
        return False
    return True
