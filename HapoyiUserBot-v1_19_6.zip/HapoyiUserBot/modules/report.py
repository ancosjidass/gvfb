"""Report: the profile (bio) of this account says ONLINE while the self runs on it and OFFLINE when it stops.

    .report on|off|status
    .report where bio|name      write the status into the bio (default) or after the last name

Every account of the fleet has its own switch (own database). `.report on` remembers your real bio / last name and
`.report off` puts it back. OFFLINE is written when the self stops on that account (normal shutdown, `.deactivate`,
license end, owner switch-off, SIGTERM/Ctrl-C). A crash / power cut / kill -9 cannot write anything: the profile then
keeps the last text until the next start.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re

from telethon import events
from telethon.errors import FloodWaitError
from telethon.tl.functions.account import UpdateProfileRequest
from telethon.tl.functions.users import GetFullUserRequest
from telethon.tl.types import InputUserSelf

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
ONLINE, OFFLINE = "ONLINE", "OFFLINE"
_TAIL = re.compile(r"\s*(?:ONLINE|OFFLINE)$")
MAX_LAST = 64


def status_text(online: bool) -> str:
    return ONLINE if online else OFFLINE


def setup(client, db):
    async def _cfg() -> dict:
        return {"on": bool(await db.get_kv("report_on", False)), "where": await db.get_kv("report_where", "bio") or "bio",
                "orig": await db.get_kv("report_orig", {}) or {}}

    async def _about() -> str:
        full = await client(GetFullUserRequest(InputUserSelf()))
        return getattr(full.full_user, "about", None) or ""

    async def _write(where: str, online: bool, orig: dict) -> None:
        text = status_text(online)
        try:
            if where == "name":
                base = _TAIL.sub("", orig.get("last_name", "")).strip()
                last = (f"{base[:MAX_LAST - len(text) - 1]} {text}").strip()
                await client(UpdateProfileRequest(last_name=last))
            else:
                await client(UpdateProfileRequest(about=text))
        except FloodWaitError as exc:
            log.warning("report: flood wait %ss", exc.seconds)
        except Exception as exc:  # noqa: BLE001
            if exc.__class__.__name__ not in {"AboutNotModifiedError", "FirstNameNotModifiedError"}:
                log.warning("report: %s: %s", exc.__class__.__name__, exc)

    async def publish(online: bool) -> None:
        cfg = await _cfg()
        if cfg["on"]:
            await _write(cfg["where"], online, cfg["orig"])

    async def _enable(where: str) -> None:
        cfg = await _cfg()
        orig = dict(cfg["orig"])
        if not orig:  # remember the real values once
            me = await client.get_me()
            about = await _about()
            orig = {"about": "" if about in (ONLINE, OFFLINE) else about, "last_name": _TAIL.sub("", me.last_name or "")}
            await db.set_kv("report_orig", orig)
        await db.set_kv("report_where", where)
        await db.set_kv("report_on", True)
        if cfg["on"] and cfg["where"] != where:
            await _restore(cfg)
        await _write(where, True, orig)

    async def _restore(cfg: dict) -> None:
        orig = cfg["orig"]
        try:
            if cfg["where"] == "name":
                await client(UpdateProfileRequest(last_name=orig.get("last_name", "")))
            else:
                await client(UpdateProfileRequest(about=orig.get("about", "")[:140]))
        except Exception as exc:  # noqa: BLE001
            log.warning("report restore: %s: %s", exc.__class__.__name__, exc)

    async def go_offline() -> None:
        """Called by the Fleet right before this account is disconnected."""
        try:
            await asyncio.wait_for(publish(False), 8)
        except Exception as exc:  # noqa: BLE001
            log.warning("report offline: %s: %s", exc.__class__.__name__, exc)

    client._hapoyi_report_offline = go_offline

    async def announce_online() -> None:
        try:
            await asyncio.sleep(1)
            await publish(True)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            log.warning("report online: %s: %s", exc.__class__.__name__, exc)

    asyncio.get_running_loop().create_task(announce_online())

    HELP = (f"📡 Report\n`{PREFIX}report on` — پروفایل: ONLINE وقتی سلف روی این اکانت روشن است، OFFLINE وقتی خاموش شد\n"
            f"`{PREFIX}report off` — خاموش + برگرداندن بیو/اسم قبلی\n`{PREFIX}report where bio|name` — نوشتن در بیو (پیش‌فرض) یا آخر Last name\n"
            f"`{PREFIX}report status`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}report(?:\s+(.*))?$"))
    async def report_cmd(event):
        parts = (event.pattern_match.group(1) or "").split()
        word = parts[0].lower() if parts else "status"
        cfg = await _cfg()
        if word == "status":
            return await event.reply(f"📡 Report: {'ON' if cfg['on'] else 'OFF'} | محل: {cfg['where']} | الان: {ONLINE if cfg['on'] else '—'}\n\n{HELP}")
        if word == "on":
            await _enable(cfg["where"] if len(parts) < 2 else ("name" if parts[1] == "name" else "bio"))
            return await event.reply(f"📡 Report روشن شد؛ پروفایل الان «{ONLINE}» است و با خاموش‌شدن سلف «{OFFLINE}» می‌شود.")
        if word == "off":
            if cfg["on"]:
                await _restore(cfg)
            await db.set_kv("report_on", False)
            await db.set_kv("report_orig", {})
            return await event.reply("📡 Report خاموش شد؛ بیو/اسم قبلی برگردانده شد.")
        if word == "where" and len(parts) > 1 and parts[1] in {"bio", "name"}:
            if cfg["on"]:
                await _enable(parts[1])
            else:
                await db.set_kv("report_where", parts[1])
            return await event.reply(f"✅ Report در {'بیو' if parts[1] == 'bio' else 'Last name'} نوشته می‌شود.")
        await event.reply(HELP)
