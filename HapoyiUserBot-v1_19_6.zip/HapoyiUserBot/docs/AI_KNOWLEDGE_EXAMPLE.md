# Template for `.aiknow import` (edit, save as .txt/.md, Reply to the file with `.aiknow import`)
# Each "# heading" becomes one note. Write in the language of your customers. Keep facts short and exact —
# the AI repeats them as written and will not invent prices or links.

# قیمت و اشتراک
اشتراک ۱ ماهه: ... تومان
اشتراک ۳ ماهه: ... تومان
برای تمدید به پشتیبانی پیام بده.

# روش خرید
۱) به @YourSupport پیام بده  ۲) پرداخت  ۳) لایسنس رو می‌گیری و در بات کنترل (@YourBot) /start می‌زنی و با شماره‌ات وارد می‌شی.

# پشتیبانی
آیدی پشتیبانی: @YourSupport — هر روز ساعت ... تا ...

# قوانین
بدون مسئولیت استفادهٔ نادرست؛ بازگشت وجه بعد از فعال‌سازی ندارد؛ ...

# سؤال‌های رایج
س: بعد از تمام شدن اشتراک چی می‌شه؟  ج: سلف روی اکانتت خاموش می‌شه و ...
س: امن هست؟  ج: ...
