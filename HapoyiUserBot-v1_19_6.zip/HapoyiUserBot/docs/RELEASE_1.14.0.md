# 1.14.0 "Aria"

* **AI on free APIs** (`services/ai.py`, `modules/ai_tools.py`): `.ask .sum .tr .trauto .stt .tts .ai`. Fail-over chain Groq → NVIDIA NIM → OpenRouter (`AI_CHAIN`);
  a provider whose daily quota is gone is parked until its reset and the next one is used; when all are used up the owner is told the time it works again.
  Per-account daily cap (`AI_DAILY_PER_ACCOUNT`, `AI_DAILY_OWNER`, resets at local midnight). `.ai afk on` = AI answers PVs while AFK (max 3 per sender, falls back to the fixed text).
* `.delmes N` (alias of `.purge`, up to 1000, Reply = from that message down): needs Delete Messages in groups.
* **Pacing** (`core/throttle.py`): per-chat + per-account limiter for sends/edits, shared pause on FloodWait. `THROTTLE=off` disables.
* `.health` (uptime, failed modules, pacing, last errors) and `.health all` (owner).
* `.autobackup on|off|now`, `.restore` + `.restore confirm` (licenses/accounts never touched; tables newer than the backup kept).
* Group: `.captcha`, `.blacklist add|del|list|on|off|sweep`, `.activity 7d`.
* Shortcuts: `.start`, `.macro`, `.m`, `.alias` (+ built-in Persian words like `.بن .خلاصه`), `.disable/.enable/.disabled`.
