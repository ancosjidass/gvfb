# 1.19.6

**Fixed: group commands sent by the other account / «ربات ...» / `.gai do` ran minutes late (3-5 min), while the same text typed by hand ran at once.**

Cause: the command message the bot sends is handed to the ~200 command handlers by `feed_handlers`. For EVERY handler a new event was built and each one
called `get_entity(chat)` and `get_me()` - real Telegram requests - i.e. ~400 requests for one `.mute`. Telegram answered with FloodWaits, the command waited
for them and ran minutes later (and a hand-typed copy, which Telethon dispatches directly, ran first).

Now the chat / sender lookups are done once per command (and cached 10 minutes per chat); building the events needs no network at all.
Test: `tests/test_v1196.py`.
