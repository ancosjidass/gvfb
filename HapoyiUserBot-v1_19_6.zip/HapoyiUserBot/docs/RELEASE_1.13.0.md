# 1.13.0 "Mirror"

* `.timer 5m 10s متن` — second value = edit interval (1s..total). Without it the old automatic step is used. Last edit lands exactly on 0, FloodWait-safe.
* `.fake <type> [30s|10m|inf]` — no 10-minute limit; no duration = unlimited. New types: round, file, location, contact. `.fake list`, `.stop fake [type]` (this chat), `.stop fake all` (everything). Menu button "⛔ خاموش‌کردن همهٔ فیک‌ها".
* `.ss` screenshots: emoji are drawn as colour pictures (Twemoji, CC-BY 4.0) in text, names, quotes and avatars; a message of 1–3 emoji is drawn big; Persian/Latin digits and RTL+emoji lines render correctly; bundled Vazirmatn font (OFL).
* XO 2-player: lobby with a "🎮 Join" button; after the opponent joins, who moves first is random.
* `.report on|off|status|where bio|name` — profile says ONLINE while the self runs on the account, OFFLINE when it stops (per account; real bio restored on `off`). Profile clock steps aside for the field Report owns.
* `.repeat on|off|list|status|clear|pause|resume` — your account replies with an exact copy of everything the chosen person writes, only in the chat where you enabled it. Self-commands typed by the target are sent but never executed.
* main.py handles SIGTERM/Ctrl-C so OFFLINE is written on `systemctl stop`.
