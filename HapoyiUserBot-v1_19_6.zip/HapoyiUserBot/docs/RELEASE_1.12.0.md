# 1.12.0 "Plus"

* `.download` / `دانلود` -> Saved Messages (server-side download, any chat, albums, progress).
* `.ss` screenshot-style sticker (utils/shot.py; RAQM or arabic-reshaper+python-bidi shaping; fonts in assets/fonts).
* Interactive `.menu` (dashboard + live actions) - every callback only touches the clicking owner's own account/database.
* Two-player `.rps` via inline mode (modules/rps_duel.py); duel stats live in the owner's database (`kv rps:duel`).
* `.every`: count token (`10m 5 text`, `x5`, `-`), range 1s..72h, 0.5s loop tick.
* modules/plus.py: timer, fake, unit, greet, dnd, bday, spend, habit, snip, fancy, hash/b64, wc, pomo, quote, unread.
  Tables are created per account (`plus_*`), module state is closure-local (nothing shared between accounts).

## 1.12.1
* `.menu` goes through inline mode first (works where the bot is not a member); fallback: bot.send_message.
* `@YourBot` typed by an account owner offers menu / RPS / XO.
* `.xo` two-player tic-tac-toe (modules/xo_duel.py), stats in the owner's DB (`kv xo:duel`).
* Help.txt button works for inline-posted menus (sent to Saved Messages).

## 1.12.2
* modules/ui_panels.py: button panels (friends/enemies, group, security, automation, media) shown next to the unchanged text sections.
* `.menu` remembers its chat (ui_panels.CHAT_CTX) so group panels work from inline-posted menus.
