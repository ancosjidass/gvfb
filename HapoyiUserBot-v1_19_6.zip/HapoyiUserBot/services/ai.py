"""Free-tier LLM gateway: many providers, unlimited keys per provider, smart fail-over.

Every provider speaks the OpenAI chat-completions dialect. The gateway works on *units*  =  (provider, model, key):

    GROQ_API_KEY=a  GROQ_API_KEY_2=b  GROQ_API_KEYS=c,d,e     -> five Groq keys (any number, any of these spellings)
    GROQ_MODELS=openai/gpt-oss-120b,openai/gpt-oss-20b        -> models for that provider (empty = built-in defaults)
    AI_PROVIDER_ORDER=groq,cerebras,gemini,nvidia,...          -> priority of the providers
    AI_CHAIN=groq:m1,nvidia:m2                                 -> OPTIONAL, forces an exact ordered list (old style)

Smart behaviour
* the same model written twice, or the same key written twice, is used once;
* a model is tried with key 1, key 2, key 3 ... before the next model is used (keys of one model are rotated by
  least-used-first, so no single key is drained: `AI_STRATEGY=balanced`; `ordered` = strictly key 1 until it is gone);
* "soft" daily caps (`AI_SOFT_<PROVIDER>`) move a unit to the back of the queue BEFORE the provider cuts it off, so
  free quotas are rarely used up completely; an over-cap unit is still used as a last resort;
* a unit that answers 429 is parked until the time the provider names (retry-after, "try again in 2m10s",
  Gemini's retryDelay); a daily quota is parked until the reset and probed again (never longer than 24 hours);
  a rejected key (401/403/402) parks every model of that key; server errors back off 30s -> 10min;
* with a pinned model (`prefer`, set from `.models`) that model is tried first and, unless `fallback=False`,
  everything else follows when it is out of quota.

When everything is parked the caller gets `AIUnavailable(reset_at)` and the owner is told when it works again.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

import aiohttp

log = logging.getLogger(__name__)

MAX_PARK = 24 * 3600  # no unit is ever switched off for longer than one day


# ====================================================================== providers
@dataclass(frozen=True)
class Provider:
    name: str
    base: str
    env: str                    # env prefix:  GROQ -> GROQ_API_KEY / GROQ_API_KEYS / GROQ_API_KEY_2 / GROQ_MODELS
    models: tuple[str, ...]     # built-in default models (used when <ENV>_MODELS is empty)
    scope: str                  # what a daily quota belongs to: "model" (per model) or "key" (whole account)
    soft: int                   # soft daily requests per unit (0 = off): the unit moves to the back after that many
    label: str
    signup: str


PROVIDERS: dict[str, Provider] = {p.name: p for p in (
    Provider("groq", "https://api.groq.com/openai/v1", "GROQ",
             ("openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"), "model", 800, "Groq", "https://console.groq.com/keys"),
    Provider("cerebras", "https://api.cerebras.ai/v1", "CEREBRAS",
             ("gpt-oss-120b", "qwen-3.8-27b"), "model", 800, "Cerebras", "https://cloud.cerebras.ai"),
    Provider("gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "GEMINI",
             ("gemini-3.8-flash",), "model", 200, "Google Gemini", "https://aistudio.google.com/apikey"),
    Provider("nvidia", "https://integrate.api.nvidia.com/v1", "NVIDIA",
             ("openai/gpt-oss-20b",), "key", 800, "NVIDIA NIM", "https://build.nvidia.com"),
    Provider("sambanova", "https://api.sambanova.ai/v1", "SAMBANOVA",
             ("gpt-oss-120b", "Meta-Llama-3.3-70B-Instruct"), "model", 15, "SambaNova", "https://cloud.sambanova.ai/apis"),
    Provider("mistral", "https://api.mistral.ai/v1", "MISTRAL",
             ("mistral-small-latest",), "key", 300, "Mistral", "https://console.mistral.ai/api-keys"),
    Provider("openrouter", "https://openrouter.ai/api/v1", "OPENROUTER",
             ("openrouter/free",), "key", 40, "OpenRouter", "https://openrouter.ai/keys"),
)}
CUSTOM = "custom"  # any other OpenAI-compatible endpoint: AI_CUSTOM_BASE + AI_CUSTOM_KEY(S) + AI_CUSTOM_MODELS
DEFAULT_ORDER = ("groq", "cerebras", "gemini", "nvidia", "sambanova", "mistral", "openrouter")
# kept for older code / tests: provider -> (base, main key variable)
BASES = {p.name: (p.base, f"{p.env}_API_KEY") for p in PROVIDERS.values()}
DEFAULT_CHAIN = ",".join(f"{prov}:{m}" for prov in DEFAULT_ORDER for m in PROVIDERS[prov].models)

TIMEOUT = aiohttp.ClientTimeout(total=50)
_PERDAY = re.compile(r"per[ _-]?day|daily|\bRPD\b|\bTPD\b", re.I)
_PERMIN = re.compile(r"per[ _-]?(?:minute|second)|\bRPM\b|\bTPM\b|\bRPS\b", re.I)
_QUOTA = re.compile(r"quota|insufficient_quota|exceeded your current", re.I)
_RETRY_IN = re.compile(r"(?:try again in|retry in|retrydelay\"?\s*:\s*\")\s*(?:(\d+)h)?\s*(?:(\d+)m(?!s))?\s*(?:([\d.]+)s)?", re.I)
_REGION = re.compile(r"location is not supported|not available in your (?:country|region)|unsupported (?:country|region)|"
                     r"(?:country|region|location)[^.]{0,40}(?:not supported|blocked|restricted|unavailable)", re.I)
_THINK = re.compile(r"<think>.*?</think>", re.S | re.I)
_DUR = re.compile(r"^(?:(\d+)h)?(?:(\d+)m(?!s))?(?:([\d.]+)s)?$")
NON_CHAT = re.compile(r"embed|rerank|whisper|tts|orpheus|guard|safeguard|moderation|reward|retriev|speech|audio|imagen|image|"
                      r"diffusion|flux|sdxl|stable-|veo|ocr|transcri|nemoretriever|clip|aqa|lyria|safety|(?:^|[-_/.])live(?:[-_/.]|$)", re.I)


class AIError(Exception):
    pass


class AINotConfigured(AIError):
    pass


class AIUnavailable(AIError):
    """Every usable quota is gone for now. `reset_at` = epoch seconds of the earliest recovery."""

    def __init__(self, reset_at: float, detail: str = ""):
        super().__init__(detail or "all AI quotas exhausted")
        self.reset_at = reset_at


@dataclass
class Entry:
    """One model of one provider, with every key that may be used for it."""
    provider: str
    model: str
    base: str
    key: str
    keys: tuple[str, ...] = field(default_factory=tuple)

    @property
    def name(self) -> str:
        return f"{self.provider}:{self.model}"

    @property
    def all_keys(self) -> tuple[str, ...]:
        return self.keys or (self.key,)


# ====================================================================== state (in memory, mirrored to a small json file)
PARKED: dict[str, tuple[float, str]] = {}   # unit name / key tag -> (parked until epoch, reason)
STATS: dict[str, int] = {}                  # unit name -> answers since start
USED: dict[str, list] = {}                  # unit name -> [utc day, requests that day]
FAILS: dict[str, int] = {}                  # unit name -> consecutive failures (drives the back-off)
LATENCY: dict[str, float] = {}              # unit name -> smoothed seconds
LAST: dict[str, Any] = {}                   # {"unit": ..., "at": ...} of the latest success
DISCOVERED: dict[str, tuple[float, list[str]]] = {}   # provider -> (when, model ids reported by its /models)
VISION_BAD: set[str] = set()                          # entries that refused an image (not vision models): skipped for images only
VISION_HINT = re.compile(r"gemini|gemma-?[34]|llama-?4|vision|(?:^|[-_/.])vl(?:[-_/.]|$)|pixtral|gpt-?(?:4o|4\.1|5)|claude|"
                         r"mistral-(?:small|medium|large)|mistral-large|qwen.*(?:vl|omni)|openrouter/free|paligemma|phi-?[34].*multimodal|llava", re.I)
_STATE = {"loaded": False, "persist": False, "saved": 0.0}


def state_path() -> Path:
    return Path(os.getenv("AI_STATE_FILE") or Path(__file__).resolve().parents[1] / "data" / "ai_state.json")


def _utc_day(now: float | None = None) -> str:
    return datetime.fromtimestamp(now or time.time(), timezone.utc).strftime("%Y-%m-%d")


def next_utc_midnight(now: float | None = None) -> float:
    dt = datetime.fromtimestamp(now or time.time(), timezone.utc)
    nxt = (dt + timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
    return nxt.timestamp()


def _load_state() -> None:
    if _STATE["loaded"]:
        return
    _STATE["loaded"] = True
    try:
        data = json.loads(state_path().read_text("utf-8"))
        now = time.time()
        for k, v in (data.get("parked") or {}).items():
            if float(v[0]) > now:
                PARKED.setdefault(k, (float(v[0]), str(v[1])))
        if data.get("day") == _utc_day():
            for k, n in (data.get("used") or {}).items():
                USED.setdefault(k, [data["day"], int(n)])
    except (OSError, ValueError, KeyError, TypeError, IndexError):
        pass


def save_state(force: bool = False) -> None:
    if not _STATE["persist"]:
        return
    now = time.time()
    if not force and now - _STATE["saved"] < 10:
        return
    _STATE["saved"] = now
    day = _utc_day(now)
    payload = {"day": day, "used": {k: v[1] for k, v in USED.items() if v[0] == day},
               "parked": {k: [v[0], v[1]] for k, v in PARKED.items() if v[0] > now}}
    try:
        path = state_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        from utils.atomic import write_text_atomic  # noqa: PLC0415

        write_text_atomic(path, json.dumps(payload))
    except OSError as exc:
        log.debug("ai state not saved: %s", exc)


def park(name: str, until: float, reason: str) -> None:
    until = min(until, time.time() + MAX_PARK)
    PARKED[name] = (until, reason)
    log.info("AI %s parked until %s (%s)", name, datetime.fromtimestamp(until).isoformat(timespec="minutes"), reason)
    save_state()


def used_today(name: str) -> int:
    rec = USED.get(name)
    return rec[1] if rec and rec[0] == _utc_day() else 0


def _bump(name: str) -> None:
    day = _utc_day()
    rec = USED.get(name)
    if rec and rec[0] == day:
        rec[1] += 1
    else:
        USED[name] = [day, 1]


# ====================================================================== configuration (.env)
def split_list(raw: str | None) -> list[str]:
    """`a, b;c  d` -> [a, b, c, d]  (quotes stripped, empty dropped, repeated values removed, order kept)."""
    out: list[str] = []
    seen: set[str] = set()
    for part in re.split(r"[\s,;]+", raw or ""):
        part = part.strip().strip("\"'")
        if part and part.lower() not in seen:
            seen.add(part.lower())
            out.append(part)
    return out


_PLACEHOLDER = re.compile(r"^(?:put_|your_|xxx|changeme|none$|null$|-+$)", re.I)


def collect_keys(env: Any, prefix: str) -> list[str]:
    """Every key of a provider, unlimited:  <P>_API_KEY, <P>_API_KEYS (comma list), <P>_API_KEY_2, _3, ... (or <P>_KEY_2).
    Order: the plain name first, then _2, _3 ...; the same key written twice counts once."""
    rx = re.compile(rf"^{re.escape(prefix)}_(?:API_)?KEYS?(?:_(\d+))?$", re.I)
    found: list[tuple[int, str, str]] = []
    for name, val in env.items():
        m = rx.match(name)
        if m and val:
            found.append((int(m.group(1)) if m.group(1) else 0, name.upper(), val))
    out: list[str] = []
    seen: set[str] = set()
    for _n, _name, val in sorted(found):
        for key in split_list(val):
            if key in seen or _PLACEHOLDER.match(key):
                continue
            seen.add(key)
            out.append(key)
    return out


def provider_keys(provider: str, env: Any = None) -> list[str]:
    env = env if env is not None else os.environ
    if provider == CUSTOM:
        return collect_keys(env, "AI_CUSTOM")
    p = PROVIDERS.get(provider)
    return collect_keys(env, p.env) if p else []


def provider_base(provider: str, env: Any = None) -> str:
    env = env if env is not None else os.environ
    if provider == CUSTOM:
        return (env.get("AI_CUSTOM_BASE") or "").strip().rstrip("/")
    p = PROVIDERS.get(provider)
    return p.base if p else ""


def _pairs(env: Any) -> list[tuple[str, str]]:
    """The ordered (provider, model) list, duplicates removed."""
    raw: list[tuple[str, str]] = []
    chain = (env.get("AI_CHAIN") or "").strip()
    if chain:
        for item in chain.split(","):
            item = item.strip()
            if ":" in item:
                prov, model = item.split(":", 1)
                raw.append((prov.strip().lower(), model.strip()))
    else:
        order = [x.lower() for x in split_list(env.get("AI_PROVIDER_ORDER"))] or list(DEFAULT_ORDER)
        order += [p for p in PROVIDERS if p not in order]
        order.append(CUSTOM)
        for prov in order:
            if prov == CUSTOM:
                models = split_list(env.get("AI_CUSTOM_MODELS") or env.get("AI_CUSTOM_MODEL"))
            elif prov in PROVIDERS:
                models = split_list(env.get(f"{PROVIDERS[prov].env}_MODELS")) or list(PROVIDERS[prov].models)
            else:
                continue
            raw += [(prov, m) for m in models]
    out, seen = [], set()
    for prov, model in raw:
        ident = (prov, model.lower())
        if model and ident not in seen:
            seen.add(ident)
            out.append((prov, model))
    return out


def load_chain(env: dict[str, str] | None = None) -> list[Entry]:
    env = env if env is not None else os.environ
    out: list[Entry] = []
    for prov, model in _pairs(env):
        if prov != CUSTOM and prov not in PROVIDERS:
            continue
        base, keys = provider_base(prov, env), provider_keys(prov, env)
        if base and keys and model.strip():
            out.append(Entry(prov, model.strip(), base, keys[0], tuple(keys)))
    return out


def unit_name(entry: Entry, idx: int) -> str:
    """`groq:model` for the first key, `groq:model#2` for the second ... (the first keeps the plain name)."""
    return entry.name if idx == 0 else f"{entry.name}#{idx + 1}"


def key_tag(provider: str, key: str) -> str:
    return f"key:{provider}:{hashlib.sha1(key.encode()).hexdigest()[:8]}"


def mask(key: str) -> str:
    return "…" + key[-4:] if len(key) > 8 else "…"


def soft_limit(provider: str) -> int:
    raw = os.getenv(f"AI_SOFT_{provider.upper()}")
    if raw is not None and raw.strip() != "":
        try:
            return max(0, int(raw))
        except ValueError:
            pass
    p = PROVIDERS.get(provider)
    return p.soft if p else 0


# ====================================================================== failure classification
def _to_seconds(text: str) -> float | None:
    m = _DUR.match((text or "").strip())
    if m and any(m.groups()):
        h, mi, s = (float(x) if x else 0.0 for x in m.groups())
        return h * 3600 + mi * 60 + s
    return None


def _retry_seconds(headers: Any, body: str) -> float | None:
    for name in ("retry-after", "x-ratelimit-reset-requests", "x-ratelimit-reset-tokens"):
        val = headers.get(name) if headers else None
        if val:
            try:
                return float(val)
            except ValueError:
                sec = _to_seconds(str(val))
                if sec is not None:
                    return sec
    m = _RETRY_IN.search(body or "")
    if m and any(m.groups()):
        h, mi, s = (float(x) if x else 0.0 for x in m.groups())
        return h * 3600 + mi * 60 + s
    return None


def classify_ex(status: int, headers: Any, body: str, now: float | None = None, fails: int = 0) -> tuple[float, str, str]:
    """(parked-until, reason, kind) of a failed response.  kind: daily | rate | auth | model | error."""
    now = now or time.time()
    body = body or ""
    cap = now + MAX_PARK
    if status == 429:
        wait = _retry_seconds(headers, body)
        daily = bool(_PERDAY.search(body)) or (bool(_QUOTA.search(body)) and not _PERMIN.search(body))
        if daily:
            if wait is not None and wait > 0:
                return min(now + max(wait + 5, 900), cap), "daily quota", "daily"
            until = next_utc_midnight(now)
            if fails > 0:  # the provider's day may end at another hour than UTC midnight: probe more often
                until = min(until, now + min(1800 * fails, 6 * 3600))
            return min(until, cap), "daily quota", "daily"
        if wait is not None and wait > 0:
            return min(now + wait + 5, cap), "rate limit", "rate"
        return now + 90, "rate limit", "rate"
    if status in (400, 401, 403) and _REGION.search(body):
        return now + 6 * 3600, "region blocked", "auth"
    if status in (401, 403):
        return now + 6 * 3600, "key rejected", "auth"
    if status == 402:
        return now + 6 * 3600, "payment required / no credit", "auth"
    if status in (404, 400) and re.search(r"model", body, re.I):
        return now + 6 * 3600, "model unavailable", "model"
    if 400 <= status < 500 and status != 408:
        return now + 300, f"http {status}", "error"
    return min(now + min(30 * (2 ** max(0, fails)), 600), cap), f"http {status}", "error"


def classify(status: int, headers: Any, body: str, now: float | None = None) -> tuple[float, str]:
    """(parked-until, reason) for a failed response."""
    until, why, _kind = classify_ex(status, headers, body, now)
    return until, why


def clean(text: str) -> str:
    return _THINK.sub("", text or "").strip()


def _extract_text(data: Any) -> str:
    try:
        content = ((data.get("choices") or [{}])[0].get("message") or {}).get("content")
    except (AttributeError, IndexError, TypeError):
        return ""
    if isinstance(content, list):
        content = "".join(str(p.get("text", "")) if isinstance(p, dict) else str(p) for p in content)
    return clean(content if isinstance(content, str) else "")


# ====================================================================== planning
def matches(entry: Entry, prefer: str | None) -> bool:
    """`provider:model` = that model | `provider` = any model of the provider | bare `model-id` = that model anywhere."""
    if not prefer:
        return False
    want = prefer.strip().lower()
    if ":" in want:
        return entry.name.lower() == want
    return entry.provider == want or entry.model.lower() == want


def _scope_key(provider: str) -> str:
    p = PROVIDERS.get(provider)
    return p.scope if p else "model"


def _pinned_extra(entries: list[Entry], prefer: str | None) -> Entry | None:
    """A pinned `provider:model` that is not in the chain (picked from the live list) still works when the provider has keys."""
    if not prefer or ":" not in prefer or any(matches(e, prefer) for e in entries):
        return None
    prov, model = prefer.split(":", 1)
    prov = prov.strip().lower()
    keys, base = provider_keys(prov), provider_base(prov)
    if keys and base and model.strip():
        return Entry(prov, model.strip(), base, keys[0], tuple(keys))
    return None


def _unit_until(entry: Entry, idx: int, key: str) -> float:
    return max(PARKED.get(unit_name(entry, idx), (0.0, ""))[0], PARKED.get(key_tag(entry.provider, key), (0.0, ""))[0])


def sees_images(entry: Entry, prefer: str | None = None) -> bool:
    """Can this model take a picture?  Known by its name; a model the owner pinned is always tried (and remembered if it refuses)."""
    if entry.name in VISION_BAD:
        return False
    return bool(VISION_HINT.search(entry.model)) or matches(entry, prefer)


def plan(entries: list[Entry], prefer: str | None = None, fallback: bool = True, strategy: str | None = None,
         now: float | None = None, vision: bool = False) -> tuple[list[tuple[Entry, int, str, str]], float | None]:
    """(ordered ready units [(entry, key index, key, unit name)], earliest recovery of the units that are parked)."""
    now = now or time.time()
    strategy = (strategy or os.getenv("AI_STRATEGY") or "balanced").strip().lower()
    entries = list(entries)
    extra = _pinned_extra(entries, prefer)
    if extra is not None:
        entries.append(extra)
    pinned, rest, parked = [], [], []
    for ei, e in enumerate(entries):
        if vision and not sees_images(e, prefer):
            continue
        for ki, key in enumerate(e.all_keys):
            name = unit_name(e, ki)
            until = _unit_until(e, ki, key)
            is_pin = matches(e, prefer)
            if until > now:
                if is_pin or fallback or not prefer:
                    parked.append(until)
                continue
            soft = soft_limit(e.provider)
            over = 1 if soft and used_today(name) >= soft else 0
            order = (over, ei, used_today(name), ki) if strategy != "ordered" else (0, ei, ki, 0)
            (pinned if is_pin else rest).append((order, (e, ki, key, name)))
    pinned.sort(key=lambda x: x[0])
    rest.sort(key=lambda x: x[0])
    ready = [u for _o, u in pinned]
    if fallback or not prefer:
        ready += [u for _o, u in rest]
    return ready, (min(parked) if parked else None)


def _earliest_after(entries: list[Entry], prefer: str | None, fallback: bool, now: float, vision: bool = False) -> float:
    _ready, earliest = plan(entries, prefer, fallback, None, now, vision)
    return earliest if earliest else min(now + 60, now + MAX_PARK)


# ====================================================================== chat
async def chat(messages: list[dict[str, str]], *, max_tokens: int = 700, temperature: float = 0.5,
               chain: list[Entry] | None = None, session: aiohttp.ClientSession | None = None,
               prefer: str | None = None, fallback: bool = True, strategy: str | None = None,
               vision: bool = False) -> tuple[str, str]:
    """Returns (answer, unit name). Raises AINotConfigured / AIUnavailable.
    `vision=True`: the messages contain images (OpenAI `image_url` parts): only models that can see are used."""
    production = chain is None
    if production:
        _STATE["persist"] = True
        _load_state()
    entries = list(chain) if chain is not None else load_chain()
    if not entries:
        raise AINotConfigured("no AI key configured")
    prefer = (prefer or "").strip() or None
    started = time.time()
    deadline = started + _num_env("AI_DEADLINE", 100)
    max_attempts = max(1, int(_num_env("AI_MAX_ATTEMPTS", 10)))
    ready, _ = plan(entries, prefer, fallback, strategy, started, vision)
    own = session is None
    sess = session or aiohttp.ClientSession(timeout=TIMEOUT)
    attempts = 0
    try:
        for e, ki, key, name in ready:
            now = time.time()
            if now > deadline or attempts >= max_attempts:
                break
            if _unit_until(e, ki, key) > now:  # parked by a parallel request meanwhile
                continue
            attempts += 1
            payload = {"model": e.model, "messages": messages, "max_tokens": max_tokens, "temperature": temperature}
            t0 = time.monotonic()
            try:
                async with sess.post(f"{e.base}/chat/completions", json=payload,
                                     headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}) as r:
                    body = await r.text()
                    status, headers = r.status, r.headers
            except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError, ValueError) as exc:
                fails = FAILS.get(name, 0)
                FAILS[name] = fails + 1
                park(name, time.time() + min(30 * (2 ** fails), 600), exc.__class__.__name__)
                continue
            text = ""
            if status == 200:
                try:
                    data = json.loads(body)
                except ValueError:
                    data = None
                if isinstance(data, dict) and data.get("error") and not data.get("choices"):
                    err = data["error"]
                    code = err.get("code") if isinstance(err, dict) else None
                    status = int(code) if isinstance(code, (int, str)) and str(code).isdigit() else 502
                    body = json.dumps(err) if not isinstance(err, str) else err
                elif data is None:
                    status = 502
                else:
                    text = _extract_text(data)
                    if not text:
                        try:  # a reasoning model that ran out of max_tokens while "thinking" is not broken: just try the next one
                            truncated = (data.get("choices") or [{}])[0].get("finish_reason") == "length"
                        except (AttributeError, IndexError, TypeError):
                            truncated = False
                        if not truncated:
                            fails = FAILS.get(name, 0)
                            FAILS[name] = fails + 1
                            park(name, time.time() + 30, "empty answer")
                        continue
            if status == 200 and text:
                STATS[name] = STATS.get(name, 0) + 1
                _bump(name)
                FAILS.pop(name, None)
                LATENCY[name] = round(0.7 * LATENCY.get(name, time.monotonic() - t0) + 0.3 * (time.monotonic() - t0), 2)
                LAST.update(unit=name, at=time.time())
                save_state()
                return text, name
            if vision and 400 <= status < 500 and status not in (401, 402, 403, 408, 429):
                VISION_BAD.add(e.name)  # it refused the picture: not a vision model - remember for pictures, keep it for text
                continue
            fails = FAILS.get(name, 0)
            until, why, kind = classify_ex(status, headers, body, fails=fails)
            FAILS[name] = fails + 1
            if kind == "auth" or (kind == "daily" and _scope_key(e.provider) == "key"):
                park(key_tag(e.provider, key), until, why)
            else:
                park(name, until, why)
    finally:
        if own:
            await sess.close()
    if vision and not any(sees_images(e, prefer) for e in entries):
        raise AINotConfigured("no model that can read images is configured")
    raise AIUnavailable(_earliest_after(entries, prefer, fallback, time.time(), vision))


def _num_env(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, "") or default)
    except ValueError:
        return default


# ====================================================================== speech to text (Groq Whisper, every Groq key is used)
async def transcribe(data: bytes, filename: str = "voice.ogg", *, language: str | None = None) -> str:
    keys = provider_keys("groq")
    if not keys:
        raise AINotConfigured("GROQ_API_KEY is needed for speech-to-text")
    now = time.time()
    earliest: float | None = None
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120)) as s:
        for i, key in enumerate(keys):
            name = "groq-stt" if i == 0 else f"groq-stt#{i + 1}"
            until = max(PARKED.get(name, (0, ""))[0], PARKED.get(key_tag("groq", key), (0, ""))[0])
            if until > now:
                earliest = until if earliest is None else min(earliest, until)
                continue
            form = aiohttp.FormData()
            form.add_field("file", data, filename=filename, content_type="application/octet-stream")
            form.add_field("model", os.getenv("AI_STT_MODEL", "whisper-large-v3-turbo"))
            form.add_field("response_format", "json")
            if language:
                form.add_field("language", language)
            try:
                async with s.post(PROVIDERS["groq"].base + "/audio/transcriptions", data=form, headers={"Authorization": f"Bearer {key}"}) as r:
                    body = await r.text()
                    if r.status == 200:
                        return (json.loads(body).get("text") or "").strip()
                    until, why, kind = classify_ex(r.status, r.headers, body)
                    park(key_tag("groq", key) if kind == "auth" else name, until, why)
                    earliest = until if earliest is None else min(earliest, until)
            except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError, ValueError) as exc:
                park(name, time.time() + 30, exc.__class__.__name__)
                if i == len(keys) - 1 and earliest is None:
                    raise AIError(f"speech service unreachable: {exc.__class__.__name__}") from exc
    raise AIUnavailable(earliest or time.time() + 60)


# ====================================================================== live model lists (/models of every provider)
def _model_ids(provider: str, payload: Any) -> list[str]:
    items = payload.get("data") if isinstance(payload, dict) else payload
    if items is None and isinstance(payload, dict):
        items = payload.get("models")
    ids: list[str] = []
    for it in items or []:
        mid = it.get("id") or it.get("name") if isinstance(it, dict) else it
        if not isinstance(mid, str):
            continue
        mid = mid[len("models/"):] if mid.startswith("models/") else mid
        if provider == "openrouter" and isinstance(it, dict):
            price = it.get("pricing") or {}
            if not (str(price.get("prompt", "1")) in {"0", "0.0"} and str(price.get("completion", "1")) in {"0", "0.0"}) and not mid.endswith(":free"):
                continue
        if NON_CHAT.search(mid):
            continue
        ids.append(mid)
    return sorted(set(ids), key=str.lower)


async def discover(providers: Iterable[str] | None = None, session: aiohttp.ClientSession | None = None,
                   env: Any = None) -> dict[str, list[str] | str]:
    """Ask each provider (that has a key) for its model list. Result: provider -> ids, or an error text."""
    env = env if env is not None else os.environ
    wanted = list(providers) if providers else [p for p in (*PROVIDERS, CUSTOM) if provider_keys(p, env) and provider_base(p, env)]
    own = session is None
    sess = session or aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25))
    out: dict[str, list[str] | str] = {}
    try:
        for prov in wanted:
            keys, base = provider_keys(prov, env), provider_base(prov, env)
            if not keys or not base:
                out[prov] = "no key"
                continue
            key = next((k for k in keys if PARKED.get(key_tag(prov, k), (0, ""))[0] <= time.time()), keys[0])
            try:
                async with sess.get(f"{base}/models", headers={"Authorization": f"Bearer {key}"}) as r:
                    body = await r.text()
                    if r.status != 200:
                        out[prov] = f"http {r.status}"
                        continue
                ids = _model_ids(prov, json.loads(body))
                DISCOVERED[prov] = (time.time(), ids)
                out[prov] = ids
            except (aiohttp.ClientError, asyncio.TimeoutError, TimeoutError, ValueError) as exc:
                out[prov] = exc.__class__.__name__
    finally:
        if own:
            await sess.close()
    return out


# ====================================================================== views for status / the .models panel
def catalog(env: Any = None, extras_per_provider: int = 30) -> list[dict[str, Any]]:
    """Configured models first (chain order), then models the providers reported live but that are not in the chain."""
    env = env if env is not None else os.environ
    now = time.time()
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()

    def row(e: Entry, configured: bool) -> dict[str, Any]:
        ready, total, soonest, reason = 0, len(e.all_keys), None, ""
        for ki, key in enumerate(e.all_keys):
            until = _unit_until(e, ki, key)
            if until <= now:
                ready += 1
            else:
                soonest = until if soonest is None else min(soonest, until)
                reason = PARKED.get(unit_name(e, ki), PARKED.get(key_tag(e.provider, key), (0, "")))[1]
        used = sum(used_today(unit_name(e, ki)) for ki in range(total))
        return {"name": e.name, "provider": e.provider, "model": e.model, "configured": configured, "keys": total, "ready": ready,
                "until": soonest if not ready else None, "reason": reason if not ready else "", "used": used,
                "id": hashlib.sha1(e.name.encode()).hexdigest()[:8]}

    for e in load_chain(env):
        rows.append(row(e, True))
        seen.add(e.name.lower())
    for prov, (_ts, ids) in DISCOVERED.items():
        keys, base = provider_keys(prov, env), provider_base(prov, env)
        if not keys or not base:
            continue
        n = 0
        for mid in ids:
            e = Entry(prov, mid, base, keys[0], tuple(keys))
            if e.name.lower() in seen or n >= extras_per_provider:
                continue
            seen.add(e.name.lower())
            rows.append(row(e, False))
            n += 1
    return rows


def _hhmm(epoch: float, tz_offset_hours: float) -> str:
    return datetime.fromtimestamp(epoch, timezone(timedelta(hours=tz_offset_hours))).strftime("%H:%M")


def status_lines(now: float | None = None, tz_offset_hours: float = 3.5) -> list[str]:
    now = now or time.time()
    rows = [r for r in catalog() if r["configured"]]
    if not rows:
        return ["❌ هیچ کلیدی تنظیم نشده (مثلاً GROQ_API_KEY / GEMINI_API_KEY / CEREBRAS_API_KEY ... در .env)."]
    lines = []
    for r in rows:
        keys = f" ({r['ready']}/{r['keys']} کلید)" if r["keys"] > 1 else ""
        if r["until"]:
            lines.append(f"⏸ {r['name']}{keys} — {r['reason']}، تا {_hhmm(r['until'], tz_offset_hours)}")
        else:
            lines.append(f"✅ {r['name']}{keys} — آماده ({r['used']} امروز)")
    return lines


def detail_lines(now: float | None = None, tz_offset_hours: float = 3.5) -> list[str]:
    """Per provider and key: ready / parked, plus the requests used today."""
    now = now or time.time()
    out: list[str] = []
    chain = load_chain()
    for prov in dict.fromkeys(e.provider for e in chain):
        entries = [e for e in chain if e.provider == prov]
        label = PROVIDERS[prov].label if prov in PROVIDERS else "Custom"
        out.append(f"{label} — {len(entries[0].all_keys)} کلید، {len(entries)} مدل")
        for ki, key in enumerate(entries[0].all_keys):
            ktag = PARKED.get(key_tag(prov, key), (0, ""))
            if ktag[0] > now:
                out.append(f"  🔑 {mask(key)}  ⏸ {ktag[1]} تا {_hhmm(ktag[0], tz_offset_hours)}")
                continue
            parts = []
            for e in entries:
                until, why = PARKED.get(unit_name(e, ki), (0, ""))
                short = e.model.rsplit("/", 1)[-1]
                parts.append(f"{'⏸' if until > now else '✅'}{short}" + (f"({_hhmm(until, tz_offset_hours)})" if until > now else f"·{used_today(unit_name(e, ki))}"))
            out.append(f"  🔑 {mask(key)}  " + "  ".join(parts))
    return out


# ====================================================================== per-account preferences (`.models`)
@dataclass
class Prefs:
    model: str = ""          # "" = smart / automatic
    fallback: bool = True    # pinned model out of quota -> use the others
    strategy: str = ""       # "" = AI_STRATEGY from .env


async def load_prefs(db: Any) -> Prefs:
    try:
        return Prefs(model=str(await db.get_kv("ai_model_pref", "") or ""),
                     fallback=bool(await db.get_kv("ai_model_fallback", True)),
                     strategy=str(await db.get_kv("ai_strategy", "") or ""))
    except Exception:  # noqa: BLE001 - a broken kv must never take the AI down
        return Prefs()
