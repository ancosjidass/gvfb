from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass
from typing import Any

from telethon import errors
from telethon.errors import RPCError
from telethon.tl.types import PeerUser

from core.identity import my_id

log = logging.getLogger(__name__)

_PERM_TTL = 30.0
_ADMIN_TTL = 60.0

class _PerClientCache:
    """Permission caches are kept ON the client object: two accounts in the same chat must never
    see each other's rights. `.clear()` drops every client's entries (used by tests)."""

    def __init__(self, attr: str):
        self.attr = attr
        self._clients: list[Any] = []

    def of(self, client: Any) -> dict:
        cache = getattr(client, self.attr, None)
        if cache is None:
            cache = {}
            setattr(client, self.attr, cache)
            self._clients.append(client)
        return cache

    def clear(self) -> None:
        for c in self._clients:
            getattr(c, self.attr, {}).clear()


_perm_cache = _PerClientCache("_hapoyi_perm_cache")
_admin_cache = _PerClientCache("_hapoyi_admin_cache")


@dataclass(frozen=True)
class PermissionResult:
    allowed: bool
    reason: str = ""


RIGHT_LABELS = {
    "ban_users": "Ban Users",
    "delete_messages": "Delete Messages",
    "pin_messages": "Pin Messages",
    "invite_users": "Invite Users",
    "change_info": "Change Group Info",
    "add_admins": "Add New Admins",
}


def explain_error(exc: BaseException) -> str:
    """Human readable (Persian) reason for a Telegram/Telethon failure."""
    if isinstance(exc, errors.FloodWaitError):
        return f"تلگرام محدودیت سرعت اعمال کرد؛ {getattr(exc, 'seconds', '?')} ثانیه صبر کن."
    table = {
        "ChatAdminRequiredError": "شما دسترسی ندارید (ادمین نیستی یا حق لازم را نداری).",
        "RightForbiddenError": "شما دسترسی ندارید (حقی را که خودت نداری نمی‌توانی بدهی).",
        "ChatAdminInviteRequiredError": "شما دسترسی ندارید (حق Invite Users لازم است).",
        "AdminsTooMuchError": "تعداد ادمین‌های گروه به سقف رسیده است.",
        "UserNotMutualContactError": "تلگرام اجازه نمی‌دهد (کاربر باید عضو گروه باشد).",
        "UserChannelsTooMuchError": "این کاربر در کانال/گروه‌های زیادی عضو است.",
        "BotGroupsBlockedError": "این ربات در گروه‌ها مسدود است.",
        "ChatWriteForbiddenError": "اجازهٔ ارسال پیام در این چت را نداری.",
        "UserAdminInvalidError": "شما دسترسی بالاتر از او ندارید (ادمینی است که خودت منصوبش نکرده‌ای).",
        "UserCreatorError": "او مالک گروه است و قابل تغییر نیست.",
        "ChatNotModifiedError": "تغییری لازم نبود (از قبل همین حالت بود).",
        "UserNotParticipantError": "این کاربر عضو گروه نیست.",
        "UserIdInvalidError": "کاربر نامعتبر است.",
        "ParticipantIdInvalidError": "کاربر نامعتبر است.",
        "PeerIdInvalidError": "چت یا کاربر نامعتبر است.",
        "ChannelPrivateError": "به این چت دسترسی نداری.",
        "ChannelInvalidError": "این چت از این عملیات پشتیبانی نمی‌کند.",
        "MessageDeleteForbiddenError": "اجازهٔ حذف این پیام را نداری.",
        "MessageIdInvalidError": "پیام نامعتبر است.",
        "BotsTooMuchError": "تعداد ربات‌ها در گروه به حد مجاز رسیده است.",
        "UsernameNotOccupiedError": "این username وجود ندارد.",
        "UsernameInvalidError": "username نامعتبر است.",
    }
    name = exc.__class__.__name__
    if name in table:
        return table[name]
    text = str(exc).strip()
    return f"{name}" + (f": {text[:120]}" if text and not isinstance(exc, RPCError) else "")


async def actor_permissions(client: Any, chat_id: int, *, fresh: bool = True) -> Any:
    now = time.monotonic()
    if not fresh:
        hit = _perm_cache.of(client).get(chat_id)
        if hit and now - hit[0] < _PERM_TTL:
            return hit[1]
    try:
        perm = await client.get_permissions(chat_id, "me")
    except Exception as exc:  # noqa: BLE001 - we only need a yes/no
        log.debug("actor permission lookup failed: %s", exc)
        return None
    _perm_cache.of(client)[chat_id] = (now, perm)
    return perm


def has_rights(permission: Any, *names: str) -> bool:
    """True when `permission` (Telethon ParticipantPermissions) grants every right in `names`."""
    if permission is None:
        return False
    if getattr(permission, "is_creator", False):
        return True
    if not getattr(permission, "is_admin", False):
        return False
    # NOTE: ParticipantPermissions exposes each right as a property (ban_users, ...);
    # it has NO `admin_rights` attribute, so we must read the properties directly.
    return all(bool(getattr(permission, n, False)) for n in names)


async def require_group_right(client: Any, chat_id: int, right: str, *, fresh: bool = True) -> PermissionResult:
    perm = await actor_permissions(client, chat_id, fresh=fresh)
    if perm is None:
        return PermissionResult(False, "نتوانستم دسترسی‌های تو را در این چت بررسی کنم.")
    if getattr(perm, "is_creator", False):
        return PermissionResult(True)
    if not getattr(perm, "is_admin", False):
        return PermissionResult(False, "در این گروه ادمین نیستی.")
    if not has_rights(perm, right):
        return PermissionResult(False, f"دسترسی {RIGHT_LABELS.get(right, right)} را نداری.")
    return PermissionResult(True)


async def require_admin(client: Any, chat_id: int) -> PermissionResult:
    """Plain 'am I an admin here' check (e.g. to list banned users)."""
    perm = await actor_permissions(client, chat_id, fresh=True)
    if perm is None:
        return PermissionResult(False, "نتوانستم دسترسی‌های تو را در این چت بررسی کنم.")
    if getattr(perm, "is_creator", False) or getattr(perm, "is_admin", False):
        return PermissionResult(True)
    return PermissionResult(False, "شما دسترسی ندارید (در این گروه ادمین نیستی).")


async def can_act_on(client: Any, chat_id: int, target: Any) -> PermissionResult:
    """Can MY account restrict/ban this user? Whether the user is an admin is irrelevant by itself:
    Telegram lets an admin with Ban Users act on another admin that this admin promoted
    (`can_edit`), and the creator on everyone but themselves. Normal members are always fine.
    When the answer cannot be determined we say yes and let Telegram be the judge.
    """
    from telethon.tl.types import (  # local import keeps module import light
        ChannelParticipantAdmin,
        ChannelParticipantCreator,
        ChatParticipantAdmin,
        ChatParticipantCreator,
    )

    try:
        tperm = await client.get_permissions(chat_id, target)
    except Exception:  # noqa: BLE001 - not a participant / unknown: let the real call decide
        return PermissionResult(True)
    part = getattr(tperm, "participant", None)
    if isinstance(part, (ChannelParticipantCreator, ChatParticipantCreator)):
        return PermissionResult(False, "او مالک گروه است؛ شما دسترسی بالاتر از او ندارید.")
    if isinstance(part, ChannelParticipantAdmin):
        if getattr(part, "can_edit", False):
            return PermissionResult(True)
        return PermissionResult(False, "او ادمینی است که شما منصوبش نکرده‌اید؛ شما دسترسی بالاتر از او ندارید.")
    if isinstance(part, ChatParticipantAdmin):
        mine = await actor_permissions(client, chat_id)
        if getattr(mine, "is_creator", False):
            return PermissionResult(True)
        return PermissionResult(False, "او ادمین است و فقط مالک گروه می‌تواند روی او عملیات انجام دهد.")
    return PermissionResult(True)


async def get_real_reply(event: Any) -> Any:
    """Reply target, ignoring the implicit 'reply to topic root' of forum groups."""
    if not getattr(event, "is_reply", False):
        return None
    rt = getattr(event.message, "reply_to", None)
    if rt is not None and getattr(rt, "forum_topic", False) and not getattr(rt, "reply_to_top_id", None):
        return None
    try:
        return await event.get_reply_message()
    except Exception:  # noqa: BLE001
        return None


def reply_to_id(event: Any) -> int | None:
    """Message id that NEW messages should reply to so they land where the command was typed.

    - command was a reply to message X      -> X   (casino/dice then reply to X)
    - plain command in a forum topic        -> topic root (keeps the message inside the topic)
    - plain command elsewhere               -> None (ordinary message)
    """
    rt = getattr(getattr(event, "message", None), "reply_to", None)
    if rt is None:
        return None
    rid = getattr(rt, "reply_to_msg_id", None)
    return int(rid) if rid else None


_INVISIBLE = re.compile("[\u200b\u200e\u200f\u202a-\u202e\u2060\u2066-\u2069\ufeff]")
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def describe_ref(raw: str | None) -> str:
    """For error messages: exactly what the command received (so hidden characters / odd digits become visible)."""
    if not raw:
        return " (هدف: Reply هم نبود و ایدی هم داده نشد)"
    odd = [f"U+{ord(ch):04X}" for ch in raw if not (ch.isascii() and ch.isprintable())]
    return f"\nدریافت‌شده: `{raw}`" + (f" — کاراکتر غیرعادی: {' '.join(odd[:6])}" if odd else "")


class BareUser:
    """Only an id (the user could not be looked up by Telegram). Enough for commands that just store the id."""

    def __init__(self, uid: int):
        self.id = int(uid)
        self.username = None
        self.first_name = None
        self.last_name = None
        self.bare = True


def clean_target(raw: str | None) -> str:
    """Make what a person (or the AI) typed as a user reference usable: Persian digits, @123456, tg://user?id=, t.me/name,
    zero-width / bidi marks, quotes, backticks."""
    t = _INVISIBLE.sub("", raw or "").translate(_DIGITS).strip().strip("`'\"“”‘’<>()[]،,؛;.:!؟")
    m = re.search(r"(?:tg://user\?id=|tg://openmessage\?user_id=)(\d+)", t, re.I)
    if m:
        return m.group(1)
    m = re.fullmatch(r"(?:https?://)?(?:t|telegram)\.me/([A-Za-z0-9_]{3,})/?(?:\?.*)?", t, re.I)
    if m:
        return "@" + m.group(1)
    m = re.fullmatch(r"@?(-?\d{3,16})", t)
    if m:
        return m.group(1)
    return t


async def _find_in_chat(client: Any, chat_id: Any, uid: int) -> Any:
    """Telegram can only address a user by id when this session has seen his access hash. Looking through the member lists of
    the chat (all / banned / muted / admins) puts it in the cache - this is what makes `.ban <id>` / `.unban <id>` work."""
    if chat_id is None:
        return None
    from telethon.tl import types as tl  # local import keeps module import light

    filters = [None] + [getattr(tl, n) for n in ("ChannelParticipantsKicked", "ChannelParticipantsBanned", "ChannelParticipantsAdmins") if hasattr(tl, n)]
    for flt in filters:
        try:
            kwargs = {"limit": 5000}
            if flt is not None:
                try:
                    kwargs["filter"] = flt("")  # Kicked / Banned need a (here empty) search text
                except TypeError:
                    kwargs["filter"] = flt()
            async for u in client.iter_participants(chat_id, **kwargs):
                if getattr(u, "id", None) == uid:
                    return u
        except Exception as exc:  # noqa: BLE001 - not allowed / not a channel: try the next list
            log.debug("member search %s failed: %s", getattr(flt, "__name__", "all"), exc)
    return None


async def _lookup_ref(client: Any, raw: str, chat_id: Any) -> Any:
    from telethon.tl.types import PeerUser  # noqa: PLC0415

    if re.fullmatch(r"-?\d+", raw):
        uid = int(raw)
        for ref in ((PeerUser(uid) if uid > 0 else uid),):
            try:
                return await client.get_entity(ref)
            except Exception as exc:  # noqa: BLE001
                log.debug("get_entity(%s) failed: %s", raw, exc)
        if uid > 0:
            return await _find_in_chat(client, chat_id, uid)
        return None
    for ref in (raw, raw if raw.startswith("@") else "@" + raw, raw.lstrip("@")):
        try:
            return await client.get_entity(ref)
        except Exception as exc:  # noqa: BLE001
            log.debug("get_entity(%r) failed: %s", ref, exc)
    return None


async def resolve_target(event: Any, explicit: str | None = None, *, bare_ok: bool = False) -> Any:
    """Resolve the command target to a Telethon entity, or None. Never raises.
    `bare_ok`: commands that only STORE the id (whitelist, blacklist, echo ...) may get a BareUser instead of None for a numeric id."""
    client = event.client
    if explicit:
        raw = clean_target(explicit)
        if not raw:
            return None
        found = await _lookup_ref(client, raw, getattr(event, "chat_id", None))
        if found is None and bare_ok and re.fullmatch(r"\d{3,16}", raw):
            return BareUser(int(raw))
        return found
    reply = await get_real_reply(event)
    if reply is None:
        return None
    try:
        sender = await reply.get_sender()
    except Exception:  # noqa: BLE001
        sender = None
    if sender is None and reply.sender_id:
        try:
            sender = await client.get_entity(PeerUser(int(reply.sender_id)))
        except Exception:  # noqa: BLE001
            sender = None
    return sender


async def ensure_target_not_self(client: Any, target: Any) -> PermissionResult:
    target_id = getattr(target, "id", target)
    if int(target_id) == await my_id(client):
        return PermissionResult(False, "نمی‌توانم خودت را هدف این عملیات قرار بدهم.")
    return PermissionResult(True)


async def target_is_admin(client: Any, chat_id: int, target: Any, *, fresh: bool = True) -> bool:
    target_id = int(getattr(target, "id", target))
    key = (chat_id, target_id)
    now = time.monotonic()
    if not fresh:
        hit = _admin_cache.of(client).get(key)
        if hit and now - hit[0] < _ADMIN_TTL:
            return hit[1]
    try:
        perm = await client.get_permissions(chat_id, target)
        result = bool(getattr(perm, "is_admin", False) or getattr(perm, "is_creator", False))
    except Exception:  # noqa: BLE001
        result = False
    _admin_cache.of(client)[key] = (now, result)
    return result
