from __future__ import annotations

from typing import Any

from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.functions.messages import DeleteChatUserRequest
from telethon.tl.types import InputPeerChannel, InputPeerChat


class UnsupportedChat(Exception):
    """Operation cannot be done in this kind of chat (e.g. mute in a legacy group)."""


async def edit_banned(client: Any, event_or_chat: Any, user: Any, rights: Any) -> None:
    """Apply ChatBannedRights to `user` in the chat of `event_or_chat`.

    Works in supergroups. In legacy basic groups only removal (ban/kick) exists.
    Raises telethon RPCError / UnsupportedChat on failure so callers can report it.
    """
    if hasattr(event_or_chat, "get_input_chat"):
        peer = await event_or_chat.get_input_chat()
    else:
        peer = await client.get_input_entity(event_or_chat)
    try:
        target = await client.get_input_entity(user)
    except Exception:  # noqa: BLE001 - Telegram only knows an id once this session has seen the user: look in the member lists
        from core.permissions import _find_in_chat  # noqa: PLC0415

        chat_id = getattr(event_or_chat, "chat_id", None) or event_or_chat
        found = await _find_in_chat(client, chat_id, int(getattr(user, "id", user)))
        if found is None:
            raise UnsupportedChat("کاربر در لیست اعضا/بن‌شده‌ها/میوت‌شده‌های این گروه پیدا نشد؛ از داخل همین گروه Reply کن یا @username بده.") from None
        target = await client.get_input_entity(found)
    if isinstance(peer, InputPeerChannel):
        await client(EditBannedRequest(peer, target, rights))
        return
    if isinstance(peer, InputPeerChat):
        if getattr(rights, "view_messages", False):
            await client(DeleteChatUserRequest(peer.chat_id, target, revoke_history=False))
            return
        raise UnsupportedChat("در گروه‌های قدیمی (غیر سوپرگروه) mute/unban ممکن نیست؛ گروه را به سوپرگروه تبدیل کن.")
    raise UnsupportedChat("این نوع چت از این عملیات پشتیبانی نمی‌کند.")
