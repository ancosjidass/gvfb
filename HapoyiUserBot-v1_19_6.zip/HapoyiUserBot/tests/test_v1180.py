"""1.18.0: `.do` picks messages by time / phrase (ids), no text limit; picture-quiz join verification; the account as a group-management bot."""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys
import time
from datetime import datetime, timezone
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from services import aiagent as A  # noqa: E402
from services import joincap as J  # noqa: E402
from tests.test_regressions import FakeClient  # noqa: E402
from tests.test_v1170 import FE, Script, dispatch, make_db, plan_json, sent_texts  # noqa: E402


# ================================================================== .do: choosing the message
class HistClient(FakeClient):
    def __init__(self, msgs):
        super().__init__()
        self._msgs = msgs

    async def get_messages(self, chat, limit=None, ids=None, **kw):
        if ids is not None:
            return next((m for m in self._msgs if m.id == ids), None)
        return list(reversed(self._msgs))[:limit]    # Telethon: newest first


def _msg(mid, hh, mm, who, text, sender=7):
    return SimpleNamespace(id=mid, date=datetime.now(timezone.utc).replace(hour=hh, minute=mm, second=0, microsecond=0), message=text, action=None,
                           sender_id=sender, sender=SimpleNamespace(first_name=who, last_name=None, title=None, username=None))


def _do_env(monkeypatch, client, *answers):
    from modules import ai_agent

    monkeypatch.setattr(A, "SEND_GAP", 0)
    monkeypatch.setattr(ai_agent, "SETTLE", 0)
    monkeypatch.setenv("TIMEZONE", "UTC")
    monkeypatch.setattr(ai_agent, "TZ", "UTC")
    client._hapoyi_me_name = "Ali"
    script = Script(*answers)
    client._hapoyi_ask_ai = script
    db = asyncio.run(make_db())
    ai_agent.setup(client, db)
    return db, script


def test_do_shows_ids_and_times_and_replies_to_the_chosen_message(monkeypatch):
    msgs = [_msg(11, 16, 59, "Sara", "صبح بخیر"), _msg(12, 17, 3, "Reza", "فلان چیز رو میخوام"), _msg(13, 17, 20, "Mina", "سلام به همه"),
            _msg(14, 17, 41, "Reza", "فلان چیز کجاست؟")]
    client = HistClient(msgs)
    db, script = _do_env(monkeypatch, client, plan_json({"text": "خوش اومدی", "reply_to": 12}))

    async def run():
        await db.set_kv("ai_ctl_granted", True)
        ev = FE(client, ".do روی پیامی که ساعت 17:03 نوشته شده و توش فلان هست ریپ بزن خوش اومدی", mid=90)
        await dispatch(client, "do_cmd", ev)
        system = script.calls[0][0]["content"]
        assert "12 | 17:03 | Reza | فلان چیز رو میخوام" in system and "RECENT MESSAGES" in system
        send = [c for c in client.calls if isinstance(c, tuple) and c[0] == "send"][-1]
        assert send[1][1] == "خوش اومدی" and send[2]["reply_to"] == 12

    asyncio.run(run())


def test_do_random_pick_only_among_the_listed_candidates(monkeypatch):
    msgs = [_msg(i, 17, i, "U", f"m{i}") for i in range(10, 16)]
    client = HistClient(msgs)
    db, _ = _do_env(monkeypatch, client, plan_json({"text": "هی", "reply_to": [11, 13, 15], "pick": "random"}), plan_json({"text": "x", "reply_to": 999}))

    async def run():
        await db.set_kv("ai_ctl_granted", True)
        await dispatch(client, "do_cmd", FE(client, ".do روی یکی از پیام های ساعت 17 شانسی ریپ بزن هی", mid=90))
        rid = [c for c in client.calls if isinstance(c, tuple) and c[0] == "send"][-1][2]["reply_to"]
        assert rid in (11, 13, 15)
        # an id that is not in the shown list is never used (no random message gets the answer)
        ev = FE(client, ".do به پیام ساعت 17 جواب بده", mid=91)
        n = len(client.calls)
        await dispatch(client, "do_cmd", ev)
        assert len(client.calls) == n and "نبود" in ev.edits[-1]

    asyncio.run(run())


def test_do_has_no_text_limit_and_long_text_is_sent_in_parts(monkeypatch):
    client = HistClient([])
    big = ("کلمه " * 1800).strip()   # ~9000 characters
    db, script = _do_env(monkeypatch, client, plan_json({"text": big}))

    async def run():
        await db.set_kv("ai_ctl_granted", True)
        ev = FE(client, ".do این متن رو بفرست: " + big, mid=90)
        await dispatch(client, "do_cmd", ev)
        parts = sent_texts(client)
        assert len(parts) >= 3 and all(len(p) <= 4096 for p in parts) and " ".join(parts).split() == big.split()
        assert script.calls[0][1]["content"].endswith(big)           # the request reaches the AI whole
    asyncio.run(run())


def test_split_text_and_wants_history():
    assert A.split_text("a" * 10000, 4000) == ["a" * 4000, "a" * 4000, "a" * 2000]
    assert A.split_text("x y", 4000) == ["x y"]
    assert A.wants_history("رو پیام ساعت 17:30 ریپ بزن") and A.wants_history("روی یکی از پیام‌ها شانسی جواب بده")
    assert not A.wants_history("هر 5 دقیقه بنویس میو")


# ================================================================== picture quiz
def test_pool_has_20_named_pictures_and_challenges_are_valid():
    pool = J.load_pool()
    assert len(pool) >= 20
    for _ in range(50):
        ch = J.make_challenge(pool)
        assert ch and len(ch.files) == 9 and len(set(ch.files)) == 9 and 1 <= ch.answer <= 9
        assert next(p for p in pool if p.file == ch.files[ch.answer - 1]).label == ch.label
    img = J.render_collage(ch.files)
    assert img[:2] == b"\xff\xd8" and len(img) > 5000


def test_fail_decision_parsing():
    assert J.parse_fail(["mute"]) == ("mute", 0)
    assert J.parse_fail(["mute", "1d"]) == ("mute", 86400)
    assert J.parse_fail(["ban"]) == ("ban", 0) and J.parse_fail(["بن", "7d"]) == ("ban", 7 * 86400)
    assert J.parse_fail(["kick"]) == ("kick", 0)
    m = J.parse_fail(["mute", "23:30"])
    assert m and m[0] == "mute" and 1 <= m[1] <= 86400
    assert J.parse_fail(["dance"]) is None and J.parse_fail(["mute", "abc"]) is None
    assert J.seconds_until_clock("17:00", "UTC", datetime(2026, 1, 1, 16, 0, tzinfo=timezone.utc)) == 3600
    assert J.seconds_until_clock("15:00", "UTC", datetime(2026, 1, 1, 16, 0, tzinfo=timezone.utc)) == 23 * 3600


class QuizClient(FakeClient):
    def __init__(self):
        super().__init__()
        self.inline = []
        self.deleted = []

    async def inline_query(self, bot, query):
        self.inline.append((bot, query))
        client = self

        class R:
            async def click(self, chat, **kw):
                client.calls.append(("click", chat))
                return SimpleNamespace(id=777)
        return [R()]

    async def delete_messages(self, chat, ids):
        self.deleted.append((chat, list(ids)))

    async def get_permissions(self, chat, user):
        return SimpleNamespace(is_admin=False, is_creator=False)


class FakeBot:
    async def get_me(self):
        return SimpleNamespace(username="HapoyiBot")


class CbEvent:
    def __init__(self, uid):
        self.sender_id, self.answers, self.edits = uid, [], []

    async def answer(self, text=None, alert=False):
        self.answers.append((text, alert))

    async def edit(self, text, **kw):
        self.edits.append((text, kw))


def _quiz_env(monkeypatch, fail=("mute", 0), tries=2, timeout=300):
    from modules import joinguard as G

    monkeypatch.setattr(G, "_bot", FakeBot())
    rights = []

    async def fake_ban(client, chat, user, r):
        rights.append((getattr(user, "id", user), r))

    async def fake_perm(client, chat, right, **kw):
        return SimpleNamespace(allowed=True, reason="")

    monkeypatch.setattr(G, "edit_banned", fake_ban)
    monkeypatch.setattr(G, "require_group_right", fake_perm)
    client = QuizClient()
    db = asyncio.run(make_db())
    ctrl = G.Controller(client, db)
    ctrl.me = 100

    async def cfg():
        await ctrl.ensure()
        await db.execute("INSERT INTO join_cfg(chat_id,mode,timeout,tries,fail,fail_secs) VALUES(?,?,?,?,?,?)", (-1001, "image", timeout, tries, fail[0], fail[1]))
        await db.execute("CREATE TABLE IF NOT EXISTS bl_users (user_id INTEGER PRIMARY KEY)")
    return G, ctrl, client, db, rights, cfg


def _is_muted(r):
    return bool(r.send_messages) and not r.view_messages


def test_new_member_is_muted_at_once_and_the_quiz_goes_through_inline(monkeypatch):
    G, ctrl, client, db, rights, cfg = _quiz_env(monkeypatch)

    async def run():
        await cfg()
        await ctrl.start(-1001, SimpleNamespace(id=555, first_name="Bob", last_name=None, username=None, bot=False))
        assert len(rights) == 1 and rights[0][0] == 555 and _is_muted(rights[0][1])
        (token, row), = ctrl.pending.items()
        assert client.inline == [("HapoyiBot", f"cap {token}")] and ("click", -1001) in client.calls
        assert row["msg_id"] == 777 and 1 <= row["answer"] <= 9 and len(row["files"]) == 9
        assert 280 <= row["deadline"] - time.time() <= 301                    # 5 minutes
        assert (await db.fetchone("SELECT 1 FROM join_pending WHERE token=?", (token,))) is not None
        ctrl.timers[token].cancel()
    asyncio.run(run())


def test_only_the_member_can_answer_and_answers_stay_on_the_buttons(monkeypatch):
    G, ctrl, client, db, rights, cfg = _quiz_env(monkeypatch, tries=3)

    async def run():
        await cfg()
        await ctrl.start(-1001, SimpleNamespace(id=555, first_name="Bob", last_name=None, username=None, bot=False))
        (token, row), = ctrl.pending.items()
        wrong = next(n for n in range(1, 10) if n != row["answer"])
        stranger = CbEvent(999)
        await ctrl.answer(stranger, token, row["answer"])
        assert stranger.answers[-1][1] is True and token in ctrl.pending and len(rights) == 1   # nothing changed for a stranger
        ev = CbEvent(555)
        await ctrl.answer(ev, token, wrong)
        assert row["wrong"] == [wrong] and f"❌" in "".join(b[0] for b in G.J.buttons(token, row["wrong"])[0] + G.J.buttons(token, row["wrong"])[1] + G.J.buttons(token, row["wrong"])[2])
        await ctrl.answer(ev, token, wrong)
        assert "قبلاً" in ev.answers[-1][0]
        ok = CbEvent(555)
        await ctrl.answer(ok, token, row["answer"])
        assert token not in ctrl.pending
        assert rights[-1][0] == 555 and not rights[-1][1].send_messages        # unmuted
        assert "تأیید شد" in ok.edits[-1][0]
        assert (await db.fetchone("SELECT 1 FROM join_pending WHERE token=?", (token,))) is None
        for t in list(ctrl.timers.values()):
            t.cancel()
    asyncio.run(run())


@pytest.mark.parametrize("fail,check", [
    (("mute", 0), lambda r: r.send_messages and r.until_date is None),
    (("mute", 3600), lambda r: r.send_messages and r.until_date is not None),
    (("ban", 0), lambda r: r.view_messages and r.until_date is None),
    (("ban", 86400), lambda r: r.view_messages and r.until_date is not None),
])
def test_wrong_answers_end_with_the_decision_of_the_chat(monkeypatch, fail, check):
    G, ctrl, client, db, rights, cfg = _quiz_env(monkeypatch, fail=fail, tries=2)

    async def run():
        await cfg()
        await ctrl.start(-1001, SimpleNamespace(id=555, first_name="Bob", last_name=None, username=None, bot=False))
        (token, row), = ctrl.pending.items()
        a, b = [n for n in range(1, 10) if n != row["answer"]][:2]
        ev = CbEvent(555)
        await ctrl.answer(ev, token, a)
        await ctrl.answer(ev, token, b)
        assert token not in ctrl.pending and check(rights[-1][1]), rights[-1]
        assert "تأیید نشد" in ev.edits[-1][0]
        for t in list(ctrl.timers.values()):
            t.cancel()
    asyncio.run(run())


def test_no_answer_in_time_applies_the_decision_and_survives_a_restart(monkeypatch):
    G, ctrl, client, db, rights, cfg = _quiz_env(monkeypatch, fail=("ban", 0), timeout=30)

    async def run():
        await cfg()
        await ctrl.start(-1001, SimpleNamespace(id=555, first_name="Bob", last_name=None, username=None, bot=False))
        (token, row), = ctrl.pending.items()
        ctrl.timers[token].cancel()
        await db.execute("UPDATE join_pending SET deadline=? WHERE token=?", (time.time() - 1, token))
        # "restart": a new controller reads the pending quiz from the database and fires the timer at once
        ctrl2 = G.Controller(client, db)
        ctrl2.me = 100
        await ctrl2.ensure()
        assert token in ctrl2.pending
        await asyncio.sleep(0.05)
        assert token not in ctrl2.pending and rights[-1][1].view_messages
    asyncio.run(run())


def test_admins_bots_and_blacklisted_are_not_quizzed_and_missing_inline_falls_back(monkeypatch):
    G, ctrl, client, db, rights, cfg = _quiz_env(monkeypatch)

    async def run():
        await cfg()
        await ctrl.start(-1001, SimpleNamespace(id=556, first_name="Bot", bot=True))
        async def admin(chat, user):
            return SimpleNamespace(is_admin=True)
        client.get_permissions = admin
        await ctrl.start(-1001, SimpleNamespace(id=557, first_name="Adm", bot=False))
        assert not rights and not ctrl.pending
        # inline fails AND the bot cannot post -> the member is unmuted again and the old sum quiz is asked
        async def adm_no(chat, user):
            return SimpleNamespace(is_admin=False)
        client.get_permissions = adm_no
        asked = []
        async def classic(chat, user, t):
            asked.append(user.id)
        client._hapoyi_classic_captcha = classic
        async def boom(bot, q):
            raise RuntimeError("inline off")
        client.inline_query = boom
        class B2(FakeBot):
            async def send_file(self, *a, **k):
                raise AssertionError("the bot must never send the quiz by itself")
            send_message = send_file
        G._bot = B2()
        await ctrl.start(-1001, SimpleNamespace(id=558, first_name="Eve", last_name=None, username=None, bot=False))
        assert asked == [558] and not rights[-1][1].send_messages and not ctrl.pending
    asyncio.run(run())


# ================================================================== the account as a group-management bot
def _gb_env(perms):
    from modules import groupbot as GB

    client = FakeClient()
    fed = []

    async def feed(sent, origin, replied):
        fed.append((sent.text, replied.id if replied else None))
    client._hapoyi_feed_handlers = feed

    async def sendm(chat, text, **kw):
        client.calls.append(("send", (chat, text), kw))
        return SimpleNamespace(id=5000, text=text)
    client.send_message = sendm
    client.me_id = 100

    async def get_perm(chat, uid):
        return perms.get(uid, SimpleNamespace(is_admin=False, is_creator=False))
    client.get_permissions = get_perm

    async def delete_messages(chat, ids):
        return None
    client.delete_messages = delete_messages
    db = asyncio.run(make_db())
    ctrl = GB.Controller(client, db)
    ctrl.me = 100
    ctrl.ready = False
    return GB, ctrl, client, db, fed


class GEvent:
    def __init__(self, text, sender, replied=None, chat=-1001):
        self.raw_text, self.sender_id, self.chat_id, self.is_group = text, sender, chat, True
        self.is_reply, self._r = replied is not None, replied
        self.message = SimpleNamespace(fwd_from=None)
        self.replied = []

    async def get_reply_message(self):
        return self._r

    async def reply(self, text, **kw):
        self.replied.append(text)
        return SimpleNamespace(delete=lambda: asyncio.sleep(0))


def _adm(**rights):
    return SimpleNamespace(is_admin=True, is_creator=False, ban_users=rights.get("ban", True), delete_messages=rights.get("delete", True),
                           pin_messages=rights.get("pin", True), change_info=True, add_admins=rights.get("promote", False))


def test_command_words_parse_in_persian_and_english():
    GB = _gb_env({})[0]
    assert GB.parse_command("سکوت 10m") == ("mute", "10m") and GB.parse_command("رفع سکوت") == ("unmute", "")
    assert GB.parse_command("/ban") == ("ban", "") and GB.parse_command(".kick @x") == ("kick", "@x") and GB.parse_command("بن") == ("ban", "")
    assert GB.parse_command("سلام") is None and GB.parse_command("/ban@SomeBot") is None and GB.parse_command("پاکسازی 20") == ("purge", "20")
    assert GB.parse_command("ادمین ها") == ("admins", "")


def test_admin_command_is_run_by_the_account_and_limited_by_his_own_rights(monkeypatch):
    perms = {7: _adm(), 8: _adm(ban=False), 9: _adm(ban=False, delete=False)}
    GB, ctrl, client, db, fed = _gb_env(perms)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        victim = SimpleNamespace(id=1, sender_id=555)
        await ctrl.handle(GEvent("سکوت 10m", 7, SimpleNamespace(id=42, sender_id=555)))
        assert fed == [(".mute 10m", 42)]
        assert client.calls[-1][2]["reply_to"] == 42
        # a stranger is ignored; an admin without Ban Users cannot ban
        await ctrl.handle(GEvent("بن", 66, SimpleNamespace(id=43, sender_id=555)))
        ev = GEvent("بن", 8, SimpleNamespace(id=44, sender_id=555))
        await ctrl.handle(ev)
        assert len(fed) == 1 and ev.replied and "شدنی نیست" in ev.replied[0]
        # my own command is never taken as an order; a turned-off chat does nothing
        await ctrl.handle(GEvent("بن", 100, SimpleNamespace(id=45, sender_id=555)))
        await db.execute("UPDATE gb_chats SET enabled=0")
        await ctrl.handle(GEvent("بن", 7, SimpleNamespace(id=46, sender_id=555)))
        assert len(fed) == 1
        # nobody acts on an admin
        await db.execute("UPDATE gb_chats SET enabled=1")
        perms[556] = _adm()
        await asyncio.sleep(1.1)
        ev = GEvent("بن", 7, SimpleNamespace(id=47, sender_id=556))
        await ctrl.handle(ev)
        assert len(fed) == 1 and "ادمین" in ev.replied[0]
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


def test_delegate_controls_the_chat_without_being_admin(monkeypatch):
    GB, ctrl, client, db, fed = _gb_env({})

    async def run():
        await ctrl.ensure()
        now = datetime.now(timezone.utc).isoformat()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(-1001,31,'mod','D',?)", (now,))
        await db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(-1001,32,'full','F',?)", (now,))
        r = SimpleNamespace(id=42, sender_id=555)
        await ctrl.handle(GEvent("بن", 31, r))
        assert fed == [(".ban", 42)]
        ev = GEvent("ارتقا", 31, r)
        await ctrl.handle(ev)
        assert len(fed) == 1 and ev.replied                       # `mod` cannot promote
        await asyncio.sleep(1.1)
        await ctrl.handle(GEvent("ارتقا", 32, r))
        assert fed[-1] == (".promote", 42)                       # `full` can
        # a delegate of THIS chat has nothing to say in another chat
        await ctrl.handle(GEvent("بن", 31, r, chat=-2002))
        assert len(fed) == 2
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


def test_delegate_panel_buttons_are_for_the_owner_only(monkeypatch):
    GB, ctrl, client, db, fed = _gb_env({})
    bot_handlers = {}

    class Bot:
        def on(self, builder):
            def deco(fn):
                bot_handlers[fn.__name__] = fn
                return fn
            return deco
    GB.attach(Bot(), None)
    GB._PANELS["tok"] = {"ctrl": ctrl, "chat": -1001, "uid": 31, "name": "D", "born": time.time(), "user": None}

    async def run():
        await ctrl.ensure()
        stranger = CbEvent(31)
        await bot_handlers["on_click"](type("E", (), {"data": b"gbd:tok:full", "sender_id": 31, "answer": stranger.answer, "edit": stranger.edit})())
        assert stranger.answers[-1][1] is True and await ctrl.delegate(-1001, 31) is None   # the delegate cannot promote himself
        owner = CbEvent(100)
        await bot_handlers["on_click"](type("E", (), {"data": b"gbd:tok:full", "sender_id": 100, "answer": owner.answer, "edit": owner.edit})())
        assert await ctrl.delegate(-1001, 31) == "full" and "کنترل کامل" in owner.edits[-1][0]
        await bot_handlers["on_click"](type("E", (), {"data": b"gbd:tok:off", "sender_id": 100, "answer": owner.answer, "edit": owner.edit})())
        assert await ctrl.delegate(-1001, 31) is None
    asyncio.run(run())
