# 1.19.6

**Fixed: group commands sent by the other account / «ربات ...» / `.gai do` ran minutes late (3-5 min), while the same text typed by hand ran at once.**

Cause: the command message the bot sends is handed to the ~200 command handlers by `feed_handlers`. For EVERY handler a new event was built and each one
called `get_entity(chat)` and `get_me()` - real Telegram requests - i.e. ~400 requests for one `.mute`. Telegram answered with FloodWaits, the command waited
for them and ran minutes later (and a hand-typed copy, which Telethon dispatches directly, ran first).

Now the chat / sender lookups are done once per command (and cached 10 minutes per chat); building the events needs no network at all.
Test: `tests/test_v1196.py`.

**New: delegate level ⚡ `god` (خدا).**
`.delegate` panel has a new button «⚡ خدا» (or `.gbot grant god @user`). A `god` delegate can run EVERY group command (also promote / demote / modai) and the bot
puts no rule of its own in the way - not even «nobody acts on an admin»: the command is handed to the real `.ban` / `.mute` ... exactly like you typing it, and
Telegram is the only judge. So it works on admins as far as YOUR account can (an admin you promoted, any member, ...), and it fails - with Telegram's reason -
when your account cannot (the group owner when you are not the owner, an admin you may not edit, an admin with equal / higher rights). Your own account is never
a target. `mod`, `full` and admins behave as before. Test: `tests/test_v1196_god.py`.
